<?php
// Configuración de la base de datos
$servername = "localhost"; // Cambia esto según tu configuración
$username = "root"; // Cambia esto por tu usuario
$password = ""; // Cambia esto por tu contraseña
$dbname = "controldistribucion"; // Cambia esto por tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta para obtener los vehículos
$sql_vehiculos = "SELECT id_vehiculo, modelo, placas FROM vehiculos";
$result_vehiculos = $conn->query($sql_vehiculos);

$vehiculos = [];
if ($result_vehiculos->num_rows > 0) {
    while ($row = $result_vehiculos->fetch_assoc()) {
        $vehiculos[] = [
            'id_vehiculo' => $row['id_vehiculo'],
            'modelo' => $row['modelo'],
            'placas' => $row['placas']
        ];
    }
}

// Inicializar variable para almacenar los datos de Z/N
$zonas_secciones = [];

// Inicializar variable para almacenar los resultados de la consulta de `shot`
$result_shot = null;

// Verificar si se ha enviado una fecha
if (isset($_POST['fecha'])) {
    $fecha = $_POST['fecha'];

    // Consulta para obtener las zonas y secciones basadas en la fecha
    $sql_vehiculodia = "SELECT idzonaseccion, id_vehiculo FROM vehiculodia WHERE fecha = ?";
    $stmt = $conn->prepare($sql_vehiculodia);
    $stmt->bind_param("s", $fecha);
    $stmt->execute();
    $result_vehiculodia = $stmt->get_result();

    // Crear un array para almacenar las zonas y secciones
    while ($row = $result_vehiculodia->fetch_assoc()) {
        $idzonaseccion = $row['idzonaseccion'];
        $id_vehiculo = $row['id_vehiculo'];

        // Obtener la zona y sección correspondiente
        $sql_zonaseccion = "SELECT Zona, Seccion FROM zonaseccion WHERE idzonaseccion = ?";
        $stmt_zona = $conn->prepare($sql_zonaseccion);
        $stmt_zona->bind_param("i", $idzonaseccion);
        $stmt_zona->execute();
        $result_zonaseccion = $stmt_zona->get_result();

        if ($result_zonaseccion->num_rows > 0) {
            $zona_seccion = $result_zonaseccion->fetch_assoc();
            $zonas_secciones[$id_vehiculo] = $zona_seccion['Zona'] . ' - ' . $zona_seccion['Seccion'];
        }
    }

    // Consulta para obtener los datos de la tabla `shot`
    $sql_shot = "SELECT OT, NUMERO_SHOT, FECHA_INICIAL, FECHA_FINAL, ESPECIALIDAD FROM `shot`";
    $result_shot = $conn->query($sql_shot);
} else {
    // Si no se ha enviado una fecha, puedes ejecutar la consulta de `shot` sin filtros
    $sql_shot = "SELECT OT, NUMERO_SHOT, FECHA_INICIAL, FECHA_FINAL, ESPECIALIDAD FROM `shot`";
    $result_shot = $conn->query($sql_shot);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="../../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../../assets/img/favicon.png">
    <title>Medicable Control y Distribucion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab :400,700" />
    <link href="../../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../../assets/css/nucleo-svg.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link id="pagestyle" href="../../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />

</head>
<body class ="g-sidenav-show bg-gray-200">
<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand m-0" href="https://medicable.com.mx" target="_blank">
        <img src="../logo-blanco.png" style="height: 300px; width: auto;" alt="main_logo">
        </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse w-auto" id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link text-white" href="../dashboard.php">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">dashboard</i>
                    </div>
                    <span class="nav-link-text ms-1">Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#ventas-dropdown" aria-controls="ventas-dropdown" aria-expanded="false" aria-label="Ventas">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">table_view</i>
                    </div>
                    <span class="nav-link-text ms-1">Ventas</span>
                </a>
                <div class="collapse show" id="ventas-dropdown">
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white" href="../ventas/NuevaOT.php">
                                <span class="nav-link-text ms-1">Nueva OT</span>
                            </a>
                        </li>
                        <li>
                            <a class="nav-link text-white" href="../ventas/OrdenTrabajo.php">
                                <span class="nav-link-text ms-1">Crear Orden de Trabajo</span>
                            </a>
                        </li>
                        <li>
                            <a class="nav-link text-white" href="../ventas/OrdenesTrabajo.php">
                                <span class="nav-link-text ms-1">Ordenes de Trabajo</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white active bg-gradient-primary" href="../logistica/OrdenDistribucion.php">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">receipt_long</i>
                    </div>
                    <span class="nav-link-text ms-1">Logistica</span>
                </a>
            </li>
            <li class="nav-item">
            <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#almacen-dropdown" aria-controls="almacen-dropdown" aria-expanded="false" aria-label="Almacen">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                    <i class="material-icons opacity-10">view_in_ar</i>
                </div>
                <span class="nav-link-text ms-1">Almacen</span>
            </a>
            <div class="collapse" id="almacen-dropdown">
                <ul class="navbar-nav">
                    <li>
                        <a class="nav-link text-white" href="../almacen/Bodega.php">
                            <span class="nav-link-text ms-1">Bodega: Recepción</span>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link text-white" href="instrucciones.php">
                            <span class="nav-link-text ms-1">Armados: Instrucciones</span>
                        </a>
                    </li>
                </ul>
            </div>
        </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#vehiculos-dropdown" aria-controls="vehiculos-dropdown" aria-expanded="false" aria-label="Vehiculos">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">format_textdirection_r_to_l</i>
                    </div>
                    <span class="nav-link-text ms-1">Vehiculos</span>
                </a>
                <div class="collapse" id="vehiculos-dropdown">
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white" href="../vehiculos/calendario.php">
                                <span class="nav-link-text ms-1">Calendario</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../pages/notifications.html">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">notifications</i>
                    </div>
                    <span class="nav-link-text ms-1">Usuarios</span>
                </a>
            </li>
        </ul>
    </div>
    <div class="sidenav-footer position-absolute w-100 bottom-0">
        <div class="mx-3">
            <a class="btn bg-gradient-primary w-100" href="https://www.medicable.com.mx" type="button">Cerrar Sesión</a>
        </div>
    </div>
</aside>
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card card-sm my-4">
                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-white text-capitalize ps-3">ORDEN DE DISTRIBUCIÓN</h6>
                        </div>
                    </div>
                    <div class="container-fluid py-4">
                        <form method="POST" action="">
                            <div class="mb-3 d-flex justify-content-center align-items-center">
                                <input type="date" class="form-control me-2" id="fechaBusqueda" name="fecha" style="width : auto;" required>
                                <button class="btn btn-primary" type="submit" style="margin-top: -2px;">Buscar</button>
                            </div>
                        </form>
                        <!-- Tabla con barra deslizadora -->
                        <div class="table-responsive " style="max-height : 60vh; overflow-y: auto;">
                            <table class="table table-bordered">
                                <thead class="thead-light">
                                    <tr>
                                        <th>OT</th>
                                        <th>NÚMERO SHOT</th>
                                        <th>FECHA INICIAL</th>
                                        <th>FECHA FINAL</th>
                                        <th>ESPECIALIDAD</th>
                                        <?php
                                        // Agregar columnas para los vehículos
                                        foreach ($vehiculos as $vehiculo) {
                                            echo "<th>" . $vehiculo['modelo'] . " - " . $vehiculo['placas'] . "</th>";
                                        }
                                        ?>
                                    </tr>
                                    <tr>
                                        <?php
                                        // Agregar celdas para los inputs Z/N
                                        echo "<td colspan='5'></td>";
                                        foreach ($vehiculos as $vehiculo) {
                                            $zona_seccion = isset($zonas_secciones[$vehiculo['id_vehiculo']]) ? $zonas_secciones[$vehiculo['id_vehiculo']] : '';
                                            echo "<td><input type='text' class='form-control' placeholder='Z/N' value='{$zona_seccion}' aria-label='Input para {$vehiculo['modelo']} - {$vehiculo['placas']}' readonly></td>";
                                        }
                                        ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($result_shot && $result_shot->num_rows > 0) {
                                        while ($row = $result_shot->fetch_assoc()) {
                                            echo "<tr>
                                                    <td>{$row['OT']}</td>
                                                    <td>{$row['NUMERO_SHOT']}</td>
                                                    <td>{$row['FECHA_INICIAL']}</td>
                                                    <td>{$row['FECHA_FINAL']}</td>
                                                    <td>{$row['ESPECIALIDAD']}</td>";
                                            // Aquí puedes agregar celdas vacías para los vehículos
                                            foreach ($vehiculos as $vehiculo) {
                                                echo "<td></td>"; // Celdas vacías para los vehículos
                                            }
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='" . (count($vehiculos) + 5) . "' class='text-center'>No hay datos disponibles</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="row mt-3">
                            <div class='col text-end'> <!-- Alineación a la derecha -->
                                <button class='btn btn-primary' onclick='imprimir()'>Imprimir</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer py-4">
                <div class="container-fluid">
                    <div class ="row align-items-center justify-content-lg-between">
                        <div class="col-lg-6 mb-lg-0 mb-4">
                            <div class="copyright text-center text-sm text-muted text-lg-start">
                                © <script>
                                    document.write(new Date().getFullYear())
                                </script>,
                                <a href="https://medicable.com.mx" class="font-weight-bold" target="_blank">Medicable</a>
                                Todos los derechos reservados.
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
</main>

<script>
    function buscar() {
        const fecha = document.getElementById('fechaBusqueda').value;
        // Aquí puedes agregar la lógica para realizar la búsqueda con la fecha seleccionada
        console.log("Buscar proyectos desde la fecha: ", fecha);
    }

    function imprimir() {
        // Aquí puedes agregar la lógica para imprimir la información de todos los vehículos
        console.log("Imprimir información de todos los vehículos");
    }
</script>

<!--Core JS Files-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="../../assets/js/core/popper.min.js"></script>
<script src="../../assets/js/core/bootstrap.min.js"></script>
<script src="../../assets/js/plugins/perfect-scrollbar.min.js"></script>
<script src="../../assets/js/plugins/smooth-scrollbar.min.js"></script>

<!-- Github buttons -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../../assets/js/material-dashboard.min.js?v=3.1.0"></script>
</body>
</html>
<?php
$conn->close();
?>