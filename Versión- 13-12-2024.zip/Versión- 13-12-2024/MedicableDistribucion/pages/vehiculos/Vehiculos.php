<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$database = "controldistribucion";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Insertar nuevo registro
if (isset($_POST['submit'])) {
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $ano = $_POST['ano'];
    $placas = $_POST['placas'];
    $engomado = $_POST['engomado'];
    $conductor = $_POST['conductor'];
    $ayudante = $_POST['ayudante'];

    $sql = "INSERT INTO vehiculos (marca, modelo, año, placas, engomado, conductor, ayudante) 
            VALUES ('$marca', '$modelo', '$ano', '$placas', '$engomado', '$conductor', '$ayudante')";
    $conn->query($sql);
}

// Actualizar registro
if (isset($_POST['update'])) {
    $id_vehiculo = $_POST['id_vehiculo'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $ano = $_POST['ano'];
    $placas = $_POST['placas'];
    $engomado = $_POST['engomado'];
    $conductor = $_POST['conductor'];
    $ayudante = $_POST['ayudante'];

    $sql = "UPDATE vehiculos SET 
            marca='$marca', modelo='$modelo', año='$ano', placas='$placas', engomado='$engomado', 
            conductor='$conductor', ayudante='$ayudante' 
            WHERE id_vehiculo='$id_vehiculo'";
    $conn->query($sql);
}

// Eliminar registro
if (isset($_GET['delete'])) {
    $id_vehiculo = $_GET['delete'];
    $sql = "DELETE FROM vehiculos WHERE id_vehiculo='$id_vehiculo'";
    $conn->query($sql);
}

// Obtener todos los registros
$sql = "SELECT * FROM vehiculos";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel ="apple-touch-icon" sizes="76x76" href="../../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../../assets/img/favicon.png">
    <title>Medicable Control y Distribucion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <link href="../../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../../assets/css/nucleo-svg.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link id="pagestyle" href="../../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
</head>
<body class="g-sidenav-show bg-gray-200">
<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand m-0" href="https://medicable.com.mx" target="_blank">
        <img src="../logo-blanco.png" style="height: 300px; width: auto;" alt="main_logo">
        </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse w-auto" id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link text-white" href="../dashboard.php">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">dashboard</i>
                    </div>
                    <span class="nav-link-text ms-1">Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#ventas-dropdown" aria-controls="ventas-dropdown" aria-expanded="false" aria-label="Ventas">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">table_view</i>
                    </div>
                    <span class="nav-link-text ms-1">Ventas</span>
                </a>
                <div class="collapse show" id="ventas-dropdown">
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white" href="../ventas/NuevaOT.php">
                                <span class="nav-link-text ms-1">Nueva OT</span>
                            </a>
                        </li>
                        <li>
                            <a class="nav-link text-white" href="../ventas/OrdenTrabajo.php">
                                <span class="nav-link-text ms-1">Crear Orden de Trabajo</span>
                            </a>
                        </li>
                        <li>
                            <a class="nav-link text-white" href="../ventas/OrdenesTrabajo.php">
                                <span class="nav-link-text ms-1">Ordenes de Trabajo</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../logistica/OrdenDistribucion.php">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">receipt_long</i>
                    </div>
                    <span class="nav-link-text ms-1">Logistica</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../../pages/virtual-reality.html">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">view_in_ar </i>
                    </div>
                    <span class="nav-link-text ms-1">Almacen</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white active bg-gradient-primary" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#vehiculos-dropdown" aria-controls="vehiculos-dropdown" aria-expanded="false" aria-label="Vehiculos">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">format_textdirection_r_to_l</i>
                    </div>
                    <span class="nav-link-text ms-1">Vehiculos</span>
                </a>
                <div class="collapse" id="vehiculos-dropdown">
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white" href="calendario.php">
                                <span class="nav-link-text ms-1">Calendario</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../pages/notifications.html">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">notifications</i>
                    </div>
                    <span class="nav-link-text ms-1">Usuarios</span>
                </a>
            </li>
        </ul>
    </div>
    <div class="sidenav-footer position-absolute w-100 bottom-0">
        <div class="mx-3">
            <a class="btn bg-gradient-primary w-100" href="https://www.creative-tim.com/product/material-dashboard-pro?ref=sidebarfree" type="button">Cerrar Sesión</a>
        </div>
    </div>
</aside>
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card card-sm my-4">
                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-white text-capitalize ps-3">Control de Vehiculos</h6>
                        </div>
                    </div>
                    <div class="container-fluid py-4 d-flex justify-content-center align-items-center" style="min-height: 75vh;">
                    <div class="container my-4">
    <h1 class="text-center mb-4">Gestión de Vehículos</h1>

    <!-- Botón para abrir el modal de registro -->
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addModal">Agregar Vehículo</button>

    <!-- Tabla de vehículos -->
    <div class="table-responsive"> <!-- Agregado para hacer la tabla responsiva -->
        <table class="table table-striped table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Marca</th>
                <th>Modelo</th>
                <th>Año</th>
                <th>Placas</th>
                <th>Engomado</th>
                <th>Conductor</th>
                <th>Ayudante</th>
                <th>Acciones</th>
            </tr>
            </thead>
            <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id_vehiculo'] ?></td>
                    <td><?= $row['marca'] ?></td>
                    <td><?= $row['modelo'] ?></td>
                    <td><?= $row['año'] ?></td>
                    <td><?= $row['placas'] ?></td>
                    <td><?= $row['engomado'] ?></td>
                    <td><?= $row['conductor'] ?></td>
                    <td><?= $row['ayudante'] ?></td>
                    <td>
                        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editModal"
                                data-id="<?= $row['id_vehiculo'] ?>"
                                data-marca="<?= $row['marca'] ?>"
                                data-modelo="<?= $row['modelo'] ?>"
                                data-ano="<?= $row['año'] ?>"
                                data-placas="<?= $row['placas'] ?>"
                                data-engomado="<?= $row['engomado'] ?>"
                                data-conductor="<?= $row['conductor'] ?>"
                                data-ayudante="<?= $row['ayudante'] ?>">Editar
                        </button>
                        <a href="?delete=<?= $row['id_vehiculo'] ?>" class="btn btn-danger btn-sm">Borrar</a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Modal para agregar vehículo -->
    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addModalLabel">Agregar Vehículo</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="marca" class="form-label">Marca</label>
                            <input type="text" class="form-control" id="marca" name="marca" required>
                        </div>
                        <div class="mb-3">
                            <label for="modelo" class="form-label">Modelo</label>
                            <input type="text" class="form-control" id="modelo" name="modelo" required>
                        </div>
                        <div class="mb-3">
                            <label for="ano" class="form-label">Año</label>
                            <input type="number" class="form-control" id="ano" name="ano" required>
                        </div>
                        <div class="mb-3">
                            <label for="placas" class="form-label">Placas</label>
                            <input type="text" class="form-control" id="placas" name="placas" required>
                        </div>
                        <div class="mb-3">
                            <label for="engomado" class="form-label">Engomado</label>
                            <input type="text" class="form-control" id="engomado" name="engomado" required>
                        </div>
                        <div class="mb- 3">
                            <label for="conductor" class="form-label">Conductor</label>
                            <input type="text" class="form-control" id="conductor" name="conductor" required>
                        </div>
                        <div class="mb-3">
                            <label for="ayudante" class="form-label">Ayudante</label>
                            <input type="text" class="form-control" id="ayudante" name="ayudante" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        <button type="submit" name="submit" class="btn btn-primary">Agregar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal para editar vehículo -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel">Editar Vehículo</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="edit_id_vehiculo" name="id_vehiculo">
                        <div class="mb-3">
                            <label for="edit_marca" class="form-label">Marca</label>
                            <input type="text" class="form-control" id="edit_marca" name="marca" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_modelo" class="form-label">Modelo</label>
                            <input type="text" class="form-control" id="edit_modelo" name="modelo" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_ano" class="form-label">Año</label>
                            <input type="number" class="form-control" id="edit_ano" name="ano" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_placas" class="form-label">Placas</label>
                            <input type="text" class="form-control" id="edit_placas" name="placas" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_engomado" class="form-label">Engomado</label>
                            <input type="text" class="form-control" id="edit_engomado" name="engomado" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_conductor" class="form-label">Conductor</label>
                            <input type="text" class="form-control" id="edit_conductor" name="conductor" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_ayudante" class="form-label">Ayudante</label>
                            <input type="text" class="form-control" id="edit_ayudante" name="ayudante" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        <button type="submit" name="update" class="btn btn-primary">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Llenar el modal de edición con los datos del vehículo seleccionado
        const editModal = document.getElementById('editModal');
        editModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            document.getElementById('edit_id_vehiculo').value = button.getAttribute('data-id');
            document.getElementById('edit_marca').value = button.getAttribute('data-marca');
            document.getElementById('edit_modelo').value = button.getAttribute('data-modelo');
            document.getElementById('edit_ano').value = button.getAttribute('data-ano');
            document.getElementById('edit_placas').value = button.getAttribute('data-placas');
            document.getElementById('edit_engomado').value = button.getAttribute('data-engomado');
            document.getElementById('edit_conductor').value = button.getAttribute('data-conductor');
            document.getElementById('edit_ayudante').value = button.getAttribute('data-ayudante');
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</div>
                </div>
            </div>
            <footer class="footer py-4">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-lg-between">
                        <div class="col-lg-6 mb-lg-0 mb-4">
                            <div class="copyright text-center text-sm text-muted text-lg-start">
                                © <script>
                                    document.write(new Date().getFullYear())
                                </script>,
                                <i class="fa fa-heart"></i>
                                <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Medicable</a>
                                Todos los derechos reservados.
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </main>

    <!--Core JS Files-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="../../assets/js/core/popper.min.js"></script>
    <script src="../../assets/js/core/bootstrap.min.js"></script>
    <script src="../../assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="../../assets/js/plugins/smooth-scrollbar.min.js"></script>

    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../../assets/js/material-dashboard.min.js?v=3.1.0"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>