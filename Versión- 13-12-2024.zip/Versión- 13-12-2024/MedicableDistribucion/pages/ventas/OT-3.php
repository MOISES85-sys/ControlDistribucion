<?php
$host = 'localhost'; // Cambia esto si tu base de datos está en otro servidor
$db = 'controldistribucion'; // Cambia esto por el nombre de tu base de datos
$user = 'root'; // Cambia esto por tu usuario de base de datos
$pass = ''; // Cambia esto por tu contraseña de base de datos

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['eliminar'])) {
        $nombreProducto = $_POST['nombre_producto'];
        $ot = $_POST['ot']; // Asegúrate de que el nombre del campo sea correcto

        // Eliminar el producto de la tabla productopaquete
        $stmt = $pdo->prepare("DELETE FROM productopaquete WHERE numero_ot = ? AND nombre_producto = ?");
        $stmt->execute([$ot, $nombreProducto]);
    } else if (isset($_POST['cargar'])) {
        // Obtener el número de OT
        $stmt = $pdo->query("SELECT numero_ot FROM `productobodega` ORDER BY `id` DESC LIMIT 1");
        $otResult = $stmt->fetch(PDO::FETCH_ASSOC);
        $numeroOt = $otResult ? $otResult['numero_ot'] : null;

        // Obtener la descripción de las instrucciones
        $descripcion = $_POST['instrucciones'];

        // Manejar la carga de la imagen
        $imagen = $_FILES['imagen']['name'];
        $target_dir = "uploads/"; // Asegúrate de que esta carpeta exista y tenga permisos de escritura
        $target_file = $target_dir . basename($imagen);
        move_uploaded_file($_FILES['imagen']['tmp_name'], $target_file);

        // Obtener los id_productos de productopaquete
        $stmt = $pdo->prepare("SELECT id_producto FROM `productopaquete` WHERE numero_ot = ?");
        $stmt->execute([$numeroOt]);
        $idProductos = $stmt->fetchAll(PDO::FETCH_COLUMN);

        // Insertar en la tabla paquete
        if ($numeroOt && !empty($idProductos)) {
            foreach ($idProductos as $idProducto) {
                $stmt = $pdo->prepare("INSERT INTO `paquete` (numero_ot, descripcion, imagen, id_producto) VALUES (?, ?, ?, ?)");
                $stmt->execute([$numeroOt, $descripcion, $imagen, $idProducto]);
            }
            
            // Mostrar alert de éxito y redirigir a OT-4.php
            echo "
            <script>
                alert('Ha sido enviado correctamente el armado.');
                window.location.href = 'OT-4.php';
            </script>
            ";
        }
    } else {
        $materialEmpacado = $_POST['materialEmpacado'];
        $cantidad = $_POST['cantidad'];
        $ot = $_POST['ot']; // Obtener el valor de OT del formulario

        // Insertar el producto en la tabla productopaquete
        $stmt = $pdo->prepare("INSERT INTO productopaquete (numero_ot, nombre_producto, cantidad) VALUES (?, ?, ?)");
        try {
            $stmt->execute([$ot, $materialEmpacado, $cantidad]);
        } catch (PDOException $e) {
            echo "Error al insertar en productopaquete: " . $e->getMessage();
        }
    }
}

function getOT() {
    global $pdo;
    $stmt = $pdo->query("SELECT numero_ot FROM `productobodega` ORDER BY `id` DESC LIMIT 1");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['numero_ot'] : null; // Cambia 'No hay OT disponible' por null
}

function getProductos() {
    global $pdo;
    $ot = getOT(); // Obtener la última OT
    if ($ot) { // Asegúrate de que $ot no sea null
        $stmt = $pdo->prepare("SELECT nombre_producto, cantidad FROM `productobodega` WHERE numero_ot = ?");
        $stmt->execute([$ot]);
        $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($productos as $producto) {
            echo "<option value='{$producto['nombre_producto']}' data-cantidad='{$producto['cantidad']}'>{$producto['nombre_producto']} (Max : {$producto['cantidad']})</option>";
        }
    } else {
        echo "<option value=''>No hay OT disponible</option>";
    }
}

function getProductosPaquete($ot) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT nombre_producto, cantidad FROM `productopaquete` WHERE numero_ot = ?");
    $stmt->execute([$ot]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <link id="pagestyle" href="../../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
</head>
<body>
<?php include "aside.php" ?>
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card card-sm my-4">                
                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-white text-capitalize ps-3">BODEGA: INSTRUCCIONES DE ARMADO DE PAQUETES</h6>
                        </div>
                    </div>
                    <div class="container-fluid py-4 d-flex flex-column align-items-center">
                        <div class="container mt-5">
                            <button id="agregarProductoBtn" class="btn btn-primary mb-3" data-toggle="modal" data-target="#agregarProductoModal">SELECCIONAR PRODUCTO</button>
                            <br>
                            <label for="instrucciones">MATERIAL DE EMPACADO</label>

                            <!-- Tabla de productos -->
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>OT</th>
                                        <th>Nombre del Producto</th>
                                        <th>Cantidad</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $ot = getOT();
                                    $productosPaquete = getProductosPaquete($ot);
                                    if ($productosPaquete) {
                                        foreach ($productosPaquete as $producto) {
                                            echo "<tr>
                                                <td>{$ot}</td>
                                                <td>{$producto['nombre_producto']}</td>
                                                <td>{$producto['cantidad']}</td>
                                                <td>
                                                    <form method='POST' style='display:inline;'>
                                                        <input type='hidden' name='nombre_producto' value='{$producto['nombre_producto']}'>
                                                        <input type='hidden' name='ot' value='{$ot}'>
                                                        <button type='submit' name='eliminar' class='btn btn-danger btn-sm'>Eliminar</button>
                                                    </form>
                                                </td>
                                            </tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='4'>No hay productos asociados a esta OT.</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>

                            <!-- Instrucciones de Empaque / Armado -->
                            <div class="form-group">
                                <label for="instrucciones">INSTRUCCIONES DE EMPAQUETADO / ARMADO</label>
                                <textarea class="form-control" id="instrucciones" name="instrucciones" rows="3" placeholder="Escribe las instrucciones aquí..."></textarea>
                            </div>

                            <!-- Botón CARGAR -->
                            <div class="text-right">
                                <form method="POST" id="formCargar" enctype="multipart/form-data">
                                    <input type="hidden" name="instrucciones" id="instruccionesHidden" value="">
                                    <div class="form-group">
                                        <label for="imagen">Agregar Foto</label>
                                        <input type="file" class="form-control" id="imagen" name="imagen" accept="image/*" required>
                                        <img id="preview" src="#" alt="Vista previa" style="display:none; max-width: 100%; margin-top: 10px;">
                                    </div>
                                    <br>
                                <button type="submit" name="cargar" class="btn btn-success" id="cargarBtn">CARGAR</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Modal -->
<div class="modal fade" id="agregarProductoModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalLabel">Agregar Producto</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="formAgregarProducto" method="POST">
                    <div class="form-group">
                        <label for="ot">OT</label>
                        <input type="text" class="form-control" id="ot" name="ot" value="<?php echo $ot; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="materialEmpacado">Material de Empacado</label>
                        <select class="form-control" id="materialEmpacado" name="materialEmpacado" required>
                            <option value="">Seleccione un producto</option>
                            <?php getProductos(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="cantidad">Cantidad</label>
                        <input type="number" class="form-control" id="cantidad" name="cantidad" required>
                        <div id="errorCantidad" class="invalid-feedback"></div> <!-- Mensaje de error -->
                    </div>
                    <br>
                    <button type="submit" class="btn btn-primary">Agregar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#materialEmpacado').change(function() {
            var selectedOption = $(this).find('option:selected');
            var cantidadDisponible = selectedOption.data('cantidad');
            $('#cantidad').attr('max', cantidadDisponible);
            $('#cantidad').val(''); // Limpiar el campo de cantidad al cambiar el producto
        });

        $('#cantidad').on('input', function() {
            var cantidadIngresada = $(this).val();
            var cantidadMaxima = $(this).attr('max');

            if (cantidadIngresada > cantidadMaxima) {
                $(this).addClass('is-invalid'); // Agregar clase para mostrar error
                $('#errorCantidad').text('No se puede ingresar más de ' + cantidadMaxima + ' unidades.'); // Mensaje de error
            } else {
                $(this).removeClass('is-invalid'); // Remover clase de error
                $('#errorCantidad').text(''); // Limpiar mensaje de error
            }
        });

        // Previsualizar la imagen seleccionada
        $('#imagen').change(function() {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#preview').attr('src', e.target.result).show();
            }
            reader.readAsDataURL(this.files[0]);
        });

        // Al enviar el formulario de CARGAR, se guarda el valor de instrucciones
        $('#formCargar').on('submit', function() {
            $('#instruccionesHidden').val($('#instrucciones').val());
        });
    });
</script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">

</body>
</html>