<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "controldistribucion";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obtener especialidades médicas
$especialidades = [];
$sql = "SELECT DISTINCT especialidad FROM medicos WHERE especialidad IS NOT NULL ORDER BY especialidad ASC"; // Filtramos los nulos y ordenamos
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $especialidades[] = $row['especialidad']; // Asegúrate de que el nombre de la columna sea correcto
    }
}

// Obtener la cantidad de médicos en "CIUDAD DE MEXICO" por especialidad
$medicosPorEstado = [];
$sql = "SELECT especialidad, COUNT(*) as cantidad FROM medicos WHERE estado = 'CIUDAD DE MEXICO' GROUP BY especialidad";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $medicosPorEstado[$row['especialidad']] = $row['cantidad'];
    }
}

// Obtener el último numero_ot y su cantidad
$sql = "SELECT numero_ot, cantidad FROM ot ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);
$otData = $result->num_rows > 0 ? $result->fetch_assoc() : null;
$numero_ot = $otData['numero_ot'] ?? null;
$cantidad_ot = $otData['cantidad'] ?? null;

// Manejar la solicitud POST para guardar los datos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    foreach ($data as $shot) {
        $ot = $shot['ot'];
        $numero_shot = $shot['numero_shot'];
        $fecha_inicial = $shot['fecha_inicial'];
        $fecha_final = $shot['fecha_final'];
        $especialidad = $shot['especialidad'];
        $cdmx = $shot['cdmx'];
        $tol = $shot['tol'];
        $qro = $shot['qro'];
        $pue = $shot['pue'];
        $gdl = $shot['gdl'];
        $mty = $shot['mty'];

        $sql = "INSERT INTO shot (OT, NUMERO_SHOT, FECHA_INICIAL, FECHA_FINAL, ESPECIALIDAD, CDMX, TOL, QRO, PUE, GDL, MTY) 
                VALUES ('$ot', '$numero_shot', '$fecha_inicial', '$fecha_final', '$especialidad', '$cdmx', '$tol', '$qro', '$pue', '$gdl', '$mty')";

        if (!$conn->query($sql)) {
            echo json_encode(['error' => $conn->error]);
            exit;
        }
    }
    echo json_encode(['success' => true]);
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Distribuir Shots</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel ="apple-touch-icon" sizes="76x76" href="../../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../../assets/img/favicon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <link href="../../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../../assets/css/nucleo-svg.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link id ```html
="pagestyle" href="../../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet"/>
</head>
<body>
<?php include "aside.php" ?>

<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card card-sm my-4">
                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-white text-capitalize ps-3">SHOTS Y ESPECIALIDADES: CONTROL Y DISTRIBUCIÓN</h6>
                        </div>
                    </div>
                    <div class="container-fluid py-4 d-flex justify-content-center align-items-center" style="min-height: 75vh;">
                        <div class="container mt-5">
                            <div class="modal fade" id="tableModal" tabindex="-1" aria-labelledby="tableModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="tableModalLabel">Cantidad Shots</h5>
                                        </div>
                                        <div class="modal-body">
                                            <label for="tableCount" class="form-label">¿En cuántos shots deseas hacer la distribución? (debe ser divisor de <?php echo $cantidad_ot; ?>)</label>
                                            <input type="number" id="tableCount" class="form-control" placeholder="Cantidad de shots" min="1">
                                        </div>
                                        <div class="modal-footer">
                                            <button id="generateTables" class="btn btn-primary">Crear</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="tableContainer"></div>

                            <div class="d-flex justify-content-end mt-4">
                                <button id="sendButton" class="btn btn-success">Enviar</button>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="footer py-4">
                    <div class="container-fluid">
                        <div class="row align-items-center justify-content-lg-between">
                            <div class="col-lg-6 mb-lg-0 mb-4">
                                <div class="copyright text-center text-sm text-muted text-lg-start">
                                    © <script>
                                        document.write(new Date().getFullYear())
                                    </script>
                                    <a href="https://www.medicable.com.mx" class="font-weight-bold" target="_blank">Medicable</a>
                                    Todos los derechos reservados.
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
</main>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const tableModal = new bootstrap.Modal(document.getElementById('tableModal'));
    const especialidades = <?php echo json_encode($especialidades); ?>; // Pasar las especialidades a JavaScript
    const medicosPorEstado = <?php echo json_encode($medicosPorEstado); ?>; // Pasar la cantidad de médicos a JavaScript

    window.onload = () => {
        tableModal.show(); // Mostrar el modal al cargar la página
    };

    document.getElementById('generateTables').addEventListener('click', () => {
        const tableCount = parseInt(document.getElementById('tableCount').value);
        
        if (!tableCount || tableCount < 1 || <?php echo $cantidad_ot; ?> % tableCount !== 0) {
            alert('Por favor, ingresa una cantidad válida de shots que sea divisor de <?php echo $cantidad_ot; ?>.');
            return;
        }

        const tableContainer = document.getElementById('tableContainer');
        // Limpiar el contenedor y generar shots
        tableContainer.innerHTML = '';
        for (let i = 0; i < tableCount; i++) {
            createShotCard(i + 1, tableContainer);
        }

        // Ocultar el modal después de generar los shots
        tableModal.hide();
    });

    function createShotCard(shotIndex, container) {
    const section = document.createElement('div');
    section.className = 'card mb-4';

    // Header de la tarjeta
    const cardHeader = document.createElement('div');
    cardHeader.className = 'card-header';
    cardHeader.textContent = `SHOT ${shotIndex}`;
    section.appendChild(cardHeader);

    // Cuerpo de la tarjeta
    const cardBody = document.createElement('div');
    cardBody.className = 'card-body';

    // Inputs de fecha inicial y final
    const dateInputs = document.createElement('div');
    dateInputs.className = 'd-flex mb-3 gap-3';

    const startDateLabel = document.createElement('label');
    startDateLabel.className = 'form-label';
    startDateLabel.innerHTML = 'Fecha Inicial:';
    const startDateInput = document.createElement('input');
    startDateInput.type = 'date';
    startDateInput.className = 'form-control';

    const endDateLabel = document.createElement('label');
    endDateLabel.className = 'form-label';
    endDateLabel.innerHTML = 'Fecha Final:';
    const endDateInput = document.createElement('input');
    endDateInput.type = 'date';
    endDateInput.className = 'form-control';

    dateInputs.appendChild(startDateLabel);
    dateInputs.appendChild(startDateInput);
    dateInputs.appendChild(endDateLabel);
    dateInputs.appendChild(endDateInput);
    cardBody.appendChild(dateInputs);

    // Botón de agregar especialidad
    const addRowButton = document.createElement('button');
    addRowButton.className = 'btn btn-primary mb-3';
    addRowButton.textContent = `Agregar Especialidad a SHOT ${shotIndex}`;
    cardBody.appendChild(addRowButton);

    // Tabla dinámica
    const table = document.createElement('table');
    table.className = 'table table-bordered text-center';
    table.innerHTML = `
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Especialidad</th>
                <th>CDMX</th>
                <th>TOL</th>
                <th>PUE</th>
                <th>QRO</th>
                <th>GDL</th>
                <th>MTY</th>
                <th>Total</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody></tbody>
    `;
    cardBody.appendChild(table);

    // Agregar filas a la tabla
    let rowCount = 1; // Contador para las filas
    addRowButton.addEventListener('click', () => {
        const tableBody = table.querySelector('tbody');
        const newRow = document.createElement('tr');

        // Número de fila
        const rowNumberCell = document.createElement('td');
        rowNumberCell.textContent = rowCount;
        newRow.appendChild(rowNumberCell);

        // Especialidad
        const specialtyCell = document.createElement('td');
        const specialtySelect = document.createElement('select');
        specialtySelect.className = 'form-select';
        especialidades.forEach(specialty => {
            const option = document.createElement('option');
            option.value = specialty;
            option.textContent = specialty;
            specialtySelect.appendChild(option);
        });
        specialtyCell.appendChild(specialtySelect);
        newRow.appendChild(specialtyCell);

        // Inputs de ciudades
        const cityInputs = {};
        ['CDMX', 'TOL', 'PUE', 'QRO', 'GDL', 'MTY'].forEach(city => {
            const cityCell = document.createElement('td');
            const cityInput = document.createElement('input');
            cityInput.type = 'number';
            cityInput.className = 'form-control text-center';
            cityInput.value = 0;
            cityInput.readOnly = true; // Hacer el input de solo lectura
            cityInputs[city] = cityInput;

            // Recalcular total al cambiar valores
            cityInput.addEventListener('input', updateRowTotal);
            cityCell.appendChild(cityInput);
            newRow.appendChild(cityCell);
        });

        // Celda de total
        const totalCell = document .createElement('td');
        const totalInput = document.createElement('input');
        totalInput.type = 'number';
        totalInput.className = 'form-control text-center';
        totalInput.value = 0;
        totalInput.readOnly = true; // Hacer el input de total de solo lectura
        totalCell.appendChild(totalInput);
        newRow.appendChild(totalCell);

        // Botón de eliminar
        const actionCell = document.createElement('td');
        const deleteButton = document.createElement('button');
        deleteButton.className = 'btn btn-danger btn-sm';
        deleteButton.textContent = 'Eliminar';
        deleteButton.addEventListener('click', () => {
            newRow.remove();
            updateRowNumbers(); // Actualizar números de fila después de eliminar
        });
        actionCell.appendChild(deleteButton);
        newRow.appendChild(actionCell);

        tableBody.appendChild(newRow);

        // Actualizar el número de la fila para la siguiente
        rowCount++;

        // Función para actualizar el total en tiempo real
        function updateRowTotal() {
            const values = Array.from(newRow.querySelectorAll('td input[type="number"]'))
                .slice(0, 6) // Solo inputs de las ciudades
                .map(input => parseInt(input.value) || 0);
            totalInput.value = values.reduce((sum, val) => sum + val, 0);
        }

        // Actualizar los inputs de ciudades al seleccionar una especialidad
        specialtySelect.addEventListener('change', () => {
            const selectedSpecialty = specialtySelect.value;
            const cantidadCDMX = medicosPorEstado[selectedSpecialty] || 0;
            
            // Solo llenar el input de CDMX
            cityInputs['CDMX'].value = cantidadCDMX; // Llenar el input de CDMX
            
            // Dejar los demás inputs en cero
            cityInputs['TOL'].value = 0;
            cityInputs['PUE'].value = 0;
            cityInputs['QRO'].value = 0;
            cityInputs['GDL'].value = 0;
            cityInputs['MTY'].value = 0;

            updateRowTotal(); // Actualizar total después de cambiar especialidad
        });
    });

    section.appendChild(cardBody);
    container.appendChild(section);
}

    document.getElementById('sendButton').addEventListener('click', async () => {
        const shots = [];
        const shotCards = document.querySelectorAll('#tableContainer .card');

        for (const card of shotCards) {
            const shotIndex = card.querySelector('.card-header').textContent.split(' ')[1];
            const startDate = card.querySelector('input[type="date"]:nth-of-type(1)').value;
            const endDate = card.querySelector('input[type="date"]:nth-of-type(2)').value;
            const specialties = card.querySelectorAll('tbody tr');

            for (const specialtyRow of specialties) {
                const specialty = specialtyRow.querySelector('select').value;
                const cityValues = Array.from(specialtyRow.querySelectorAll('input[type="number"]')).map(input => parseInt(input.value) || 0);
                const [cdmx, tol, qro, pue, gdl, mty] = cityValues;

                shots.push({
                    ot: <?php echo json_encode($numero_ot); ?>,
                    numero_shot: shotIndex,
                    fecha_inicial: startDate,
                    fecha_final: endDate,
                    especialidad: specialty,
                    cdmx,
                    tol,
                    qro,
                    pue,
                    gdl,
                    mty
                });
            }
        }

        // Enviar los datos al backend
        const response = await fetch('', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(shots)
        });

        if (response.ok) {
            alert('Datos enviados correctamente');
            window.location.href = 'finot.php'; // Redirigir a finot.php
        } else {
            alert('Error al enviar los datos');
        }
    });
</script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">

</body>
</html>