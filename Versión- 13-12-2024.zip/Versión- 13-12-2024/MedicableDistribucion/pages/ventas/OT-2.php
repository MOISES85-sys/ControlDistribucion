<?php
// Configuración de la conexión a la base de datos
$servername = "localhost"; // Cambia esto según tu servidor
$username = "root"; // Cambia esto por tu usuario
$password = ""; // Cambia esto por tu contraseña
$dbname = "controldistribucion"; // Cambia esto por tu base de datos

// Crear conexión
$conexion = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Inicializar la variable $ot
$ot = "";

// Ejecutar la consulta para obtener el número de OT
$query = "SELECT numero_ot FROM `ordenes_trabajo` ORDER BY id DESC LIMIT 1"; // Cambiado para obtener la última OT
$result = $conexion->query($query);

// Verificar si hay resultados
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Obtener el número de OT y agregar el prefijo
    $ot = "OT-" . $row['numero_ot'];
} else {
    $ot = "OT-"; // Manejar el caso en que no haya resultados
}

// Manejar la inserción de productos
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['nombreEmpresa'])) {
    $nombre_producto = $_POST['nombreEmpresa'];
    $cantidad_producto = $_POST['cantidad_producto'];
    $bodega = $_POST['ejecutivo']; // Obtener bodega del formulario
    $fecha_estimada = $_POST['fecha_llegada']; // Obtener fecha estimada del formulario

    // Insertar en la base de datos
    $stmt = $conexion->prepare("INSERT INTO productobodega (numero_ot, nombre_producto, cantidad, bodega, fecha_estimada) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiss", $ot, $nombre_producto, $cantidad_producto, $bodega, $fecha_estimada);
    $stmt->execute();
    $stmt->close();
}

// Obtener los productos de la base de datos
$productos = [];
$query = "SELECT * FROM productobodega WHERE numero_ot = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("s", $ot);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $productos[] = $row;
}
$stmt->close();

// Manejar la eliminación de productos
if (isset($_POST['eliminar_id'])) {
    $eliminar_id = $_POST['eliminar_id'];
    $stmt = $conexion->prepare("DELETE FROM productobodega WHERE id = ?");
    $stmt->bind_param("i", $eliminar_id);
    $stmt->execute();
    $stmt->close();

    // Redireccionar para evitar reenvío del formulario
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Manejar la actualización de productos
if (isset($_POST['actualizar_id'])) {
    $actualizar_id = $_POST['actualizar_id'];
    $nuevo_nombre = $_POST['nuevo_nombre'];
    $nueva_cantidad = $_POST['nueva_cantidad'];
    $nueva_bodega = $_POST['nueva_bodega'];
    $nueva_fecha = $_POST['nueva_fecha'];

    $stmt = $conexion->prepare("UPDATE productobodega SET nombre_producto = ?, cantidad = ?, bodega = ?, fecha_estimada = ? WHERE id = ?");
    $stmt->bind_param("sissi", $nuevo_nombre, $nueva_cantidad, $nueva_bodega, $nueva_fecha, $actualizar_id);
    $stmt->execute();
    $stmt->close();

    // Redireccionar para evitar reenvío del formulario
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Cerrar la conexión
$conexion->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="../../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../../assets/img/favicon.png">
  <title>Medicable Control y Distribucion</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min .css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
  <link href="../../assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="../../assets/css/nucleo-svg.css" rel="stylesheet" />
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <link id="pagestyle" href="../../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
</head>
<body class="g-sidenav-show bg-gray-200">
<?php include "aside.php" ?>

<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card card-sm my-4">                
            <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                    <h6 class="text-white text-capitalize ps-3">BODEGA: ENVÍO - RECEPCIÓN</h6>
                </div>
            </div>
            <div class="container-fluid py-4 d-flex flex-column align-items-center">
                <div class="mb-3 w-100">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductModal">Agregar Producto a Bodega</button>
                </div>

                <!-- Modal para agregar producto -->
                <div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addProductModalLabel">Material de Empacado</h5>
                            <button type="button" class="btn-close ms-auto" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                            <div class="modal-body">
                                <form method="POST" action="">
                                    <div class="mb-3">
                                        <label for="nombreEmpresa" class="form-label">Nombre del producto</label>
                                        <input type="text" class="form-control" id="nombreEmpresa" name="nombreEmpresa" required>
                                        <div class="invalid-feedback">Por favor, ingrese el nombre del producto.</div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="cantidad_producto" class="form-label">Cantidad:</label>
                                        <input type="number" class="form-control" id="cantidad_producto" name="cantidad_producto" required>
                                        <div class="invalid-feedback">Por favor, ingrese la cantidad del producto.</div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="ejecutivo" class="form-label">Bodega:</label>
                                        <select class="form-select" id="ejecutivo" name="ejecutivo" required>
                                            <option selected disabled value="">Seleccione una Bodega</option>
                                            <option value="Chihuahua">CDMX, Chihuahua</option>
                                            <option value="Desierto">CDMX, Desierto</option>
                                            <option value="Monterrey">MONTERREY, Monterrey</option>
                                            <option value="Guadalajara">GUADALAJARA, Guadalajara</option>
                                        </select>
                                        <div class="invalid-feedback">Por favor, seleccione una bodega.</div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="fecha_llegada" class="form-label">Fecha Estimada de Llegada:</label>
                                        <input type="date" class="form-control" id="fecha_llegada" name="fecha_llegada" required>
                                        <div class="invalid-feedback"> Por favor, seleccione una fecha.</div>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Agregar Producto</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <table class="table table-striped table-bordered table-hover mt-3">
                    <thead class="table-dark">
                        <tr>
                            <th>Nombre del Producto</th>
                            <th>Cantidad</th>
                            <th>Bodega</th>
                            <th>Fecha Estimada</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($productos as $producto): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($producto['nombre_producto']); ?></td>
                                <td><?php echo htmlspecialchars($producto['cantidad']); ?></td>
                                <td><?php echo htmlspecialchars($producto['bodega']); ?></td>
                                <td><?php echo htmlspecialchars($producto['fecha_estimada']); ?></td>
                                <td>
                                    <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $producto['id']; ?>">Editar</button>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="eliminar_id" value="<?php echo $producto['id']; ?>">
                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form>
                                </td>
                            </tr>

                            <!-- Modal para editar producto -->
                            <div class="modal fade" id="editModal<?php echo $producto['id']; ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="editModalLabel">Editar Producto</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form method="POST">
                                                <input type="hidden" name="actualizar_id" value="<?php echo $producto['id']; ?>">
                                                <div class="mb-3">
                                                    <label for="nuevo_nombre" class="form-label">Nombre del Producto</label>
                                                    <input type="text" class="form-control" name="nuevo_nombre" value="<?php echo htmlspecialchars($producto['nombre_producto']); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="nueva_cantidad" class="form-label">Nueva Cantidad</label>
                                                    <input type="number" class="form-control" name="nueva_cantidad" value="<?php echo htmlspecialchars($producto['cantidad']); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="nueva_bodega" class="form-label">Bodega</label>
                                                    <select class="form-select" name="nueva_bodega" required>
                                                        <option value="Chihuahua" <?php echo ($producto['bodega'] == 'Chihuahua') ? 'selected' : ''; ?>>CDMX, Chihuahua</option>
                                                        <option value="Desierto" <?php echo ($producto['bodega'] == 'Desierto') ? 'selected' : ''; ?>>CDMX, Desierto</option>
                                                        <option value="Monterrey" <?php echo ($producto['bodega'] == 'Monterrey') ? 'selected' : ''; ?>>MONTERREY, Monterrey</option>
                                                        <option value="Guadalajara" <?php echo ($producto['bodega'] == 'Guadalajara') ? 'selected' : ''; ?>>GUADALAJARA, Guadalajara</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="nueva_fecha" class="form-label">Fecha Estimada</label>
                                                    <input type="date" class="form-control" name="nueva_fecha" value="<?php echo htmlspecialchars($producto['fecha_estimada']); ?>" required>
                                                </div>
                                                <button type="submit" class="btn btn-primary">Actualizar</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <!-- Botón para redirigir a OT-3.php alineado a la derecha -->
                <div class="text-end mt-4 w-100">
                    <a href="OT-3.php" class="btn btn-success">Siguiente</a>
                </div>
            </div>
        </div>
      </div>
      <footer class="footer py-4">
        <div class="container-fluid">
          <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
              <div class="copyright text-center text-sm text-muted text-lg-start">
                <script>
                  document.write(new Date().getFullYear())
                </script>,
                <a href="https://www.medicable.com.mx" class="font-weight-bold" target="_blank">Medicable</a>
                Todos los derechos reservados.
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </main>
  
  <!--   Core JS Files   -->
  <script src="../../assets/js/core/popper.min.js"></script>
  <script src="../../assets/js/core/bootstrap.min.js"></script>
  <script src="../../assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="../../assets/js/plugins/smooth-scrollbar.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Bundle JS (incluye Popper) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>