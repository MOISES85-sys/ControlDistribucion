<?php
// Configuración de la base de datos
$host = 'localhost'; // Cambia esto si tu base de datos está en otro servidor
$dbname = 'controldistribucion'; // Cambia esto por el nombre de tu base de datos
$username = 'root'; // Cambia esto por tu usuario de base de datos
$password = ''; // Cambia esto por tu contraseña de base de datos

try {
    // Crear conexión
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Consulta SQL
    $sql = "SELECT numero_ot, nombre_empresa, nombre_contacto, correo, marca, fecha_inicio, fecha_fin, cantidad, paqueteentregar, descripcion FROM `ot`";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Obtener los resultados
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="../../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../../assets/img/favicon.png">
    <title>Medicable Control y Distribucion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link href="../../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../../assets/css/nucleo-svg.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link id="pagestyle" href="../../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
</head>
<body class="g-sidenav-show bg-gray-200">

<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand m-0" href="https://medicable.com.mx" target="_blank">
        <img src="../logo-blanco.png" class="navbar-brand-img h-100" alt="main_logo">
        </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse w-auto" id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link text-white" href="../dashboard.php">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">dashboard</i>
                    </div>
                    <span class="nav-link-text ms-1">Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#ventas-dropdown" aria-controls="ventas-dropdown" aria-expanded="false" aria-label="Ventas">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">table_view</i>
                    </div>
                    <span class="nav-link-text ms-1">Ventas</span>
                </a>
                <div class="collapse show" id ="ventas-dropdown">
                    <ul ```php
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white" href="NuevaOT.php">
                                <span class="nav-link-text ms-1">Nueva OT</span>
                            </a>
                        </li>
                        <li>
                            <a class="nav-link text-white" href="OrdenTrabajo.php">
                                <span class="nav-link-text ms-1">Crear Orden de Trabajo</span>
                            </a>
                        </li>
                        <li>
                            <a class="nav-link text-white active bg-gradient-primary" href="OrdenesTrabajo.php">
                                <span class="nav-link-text ms-1">Ordenes de Trabajo</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../logistica/OrdenDistribucion.php">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">receipt_long</i>
                    </div>
                    <span class="nav-link-text ms-1">Logistica</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#almacen-dropdown" aria-controls="almacen-dropdown" aria-expanded="false" aria-label="Almacen">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">view_in_ar</i>
                    </div>
                    <span class="nav-link-text ms-1">Almacen</span>
                </a>
                <div class="collapse" id="almacen-dropdown">
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white" href="../almacen/Bodega.php">
                                <span class="nav-link-text ms-1">Bodega: Recepción</span>
                            </a>
                        </li>
                        <li>
                            <a class="nav-link text-white" href="../almacen/instrucciones.php">
                                <span class="nav-link-text ms-1">Armados: Instrucciones</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#vehiculos-dropdown" aria-controls="vehiculos-dropdown" aria-expanded="false" aria-label="Vehiculos">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">format_textdirection_r_to_l</i>
                    </div>
                    <span class="nav-link-text ms-1">Vehiculos</span>
                </a>
                <div class="collapse" id="vehiculos-dropdown">
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white" href="../vehiculos/calendario.php">
                                <span class="nav-link-text ms-1">Calendario</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../pages/notifications.html">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">notifications</i>
                    </div>
                    <span class="nav-link-text ms-1">Usuarios</span>
                </a>
            </li>
        </ul>
    </div>
    <div class="sidenav-footer position-absolute w-100 bottom-0">
        <div class="mx-3">
            <a class="btn bg-gradient-primary w-100" href="https://www.medicable.com.mx" type="button">Cerrar Sesión</a>
        </div>
    </div>
</aside>

<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card card-sm my-4">
                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-white text-capitalize ps-3">ORDENES DE TRABAJO</h6>
                        </div>
                    </div>
                    <div class="container-fluid py-4">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover table-bordered">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Número OT</th>
                                        <th>Nombre Empresa</th>
                                        <th>Nombre Contacto</th>
                                        <th>Correo</th>
                                        <th>Marca</th>
                                        <th>Fecha Inicio</th>
                                        <th>Fecha Fin</th>
                                        <th>Cantidad</th>
                                        <th>Paquete a Entregar</th>
                                        <th>Descripción</th>
                                        <th>Acciones</th> <!-- Nueva columna para acciones -->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!empty($result)): ?>
                                        <?php foreach ($result as $row): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($row['numero_ot']); ?></td>
                                                <td><?php echo htmlspecialchars($row['nombre_empresa']); ?></td>
                                                <td><?php echo htmlspecialchars($row['nombre_contacto']); ?></td>
                                                <td><?php echo htmlspecialchars($row['correo']); ?></td>
                                                <td><?php echo htmlspecialchars($row['marca']); ?></td>
                                                <td><?php echo htmlspecialchars($row['fecha_inicio']); ?></td>
                                                <td><?php echo htmlspecialchars($row['fecha_fin']); ?></td>
                                                <td><?php echo htmlspecialchars($row['cantidad']); ?></td>
                                                <td><?php echo htmlspecialchars($row['paqueteentregar']); ?></td>
                                                <td><?php echo htmlspecialchars($row['descripcion']); ?></td>
                                                <td>
                                                    <button class="btn btn-info btn-sm" onclick="imprimirFila(this)">Imprimir</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="10" class="text-center">No hay resultados disponibles</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer py-4">
            <div class="container-fluid">
                <div class="row align-items-center justify-content-lg-between">
                    <div class="col-lg-6 mb-lg-0 mb-4">
                        <div class="copyright text-center text-sm text-muted text-lg-start">
                            © <script>
                                document.write(new Date().getFullYear())
                            </script>,
                            <a href="https://www.medicable.com.mx" class="font-weight-bold" target="_blank">Medicable</a>
                            Todos los derechos reservados.
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</main>

<!-- Estilo CSS adicional para la tabla -->
<style>
    .table {
        margin-top: 20px;
    }
    .table th {
        background-color: #000000; /* Color de fondo para el encabezado */
        color: white; /* Color del texto del encabezado */
    }
    .table td {
        vertical-align: middle; /* Alinear verticalmente el contenido de las celdas */
    }
    .table-striped tbody tr:nth-of-type(odd) {
        background-color: #f9f9f9; /* Color de fondo para filas impares */
    }
    .table-hover tbody tr:hover {
        background-color: #e9ecef; /* Color de fondo al pasar el mouse */
    }
    .table-bordered {
        border: 1px solid #dee2e6; /* Borde de la tabla */
    }
    .table-bordered th,
    .table-bordered td {
        border: 1px solid #dee2e6; /* Borde de las celdas */
    }
</style>

<script>
    function imprimirFila(button) {
        // Obtener la fila del botón que fue presionado
        var row = button.closest('tr');
        // Crear un nuevo elemento de ventana para imprimir
        var printWindow = window.open('', '', 'height=400,width=600');
        printWindow.document.write('<html><head><title>Imprimir Fila</title>');
        printWindow.document.write('</head><body>');
        printWindow.document.write('<h3>Detalles de la Orden de Trabajo</h3>');
        printWindow.document.write('<table border="1" style="width:100%; border-collapse:collapse;">');
        printWindow.document.write('<tr><th>Número OT</th><th>Nombre Empresa</th><th>Nombre Contacto</th><th>Correo</th><th>Marca</th><th>Fecha Inicio</th><th>Fecha Fin</th><th>Cantidad</th><th>Paquete Entregar</th><th>Descripción</th></tr>');
        
        // Obtener los datos de la fila
        var cells = row.getElementsByTagName('td');
        printWindow.document.write('<tr>');
        for (var i = 0; i < cells.length - 1; i++) { // Excluir la última celda que contiene el botón
            printWindow.document.write('<td>' + cells[i].innerHTML + '</td>');
        }
        printWindow.document.write('</tr>');
        printWindow.document.write('</table>');
        printWindow.document.write('</body></html>');
        printWindow.document.close(); // Cerrar el documento
        printWindow.print(); // Abrir el diálogo de impresión
    }
</script>

<!--   Core JS Files   -->
<script src="../../assets/js/core/popper.min.js"></script>
<script src="../../assets/js/core/bootstrap.min.js"></script>
<script src="../../assets/js/plugins/perfect-scrollbar.min.js"></script>
<script src="../../assets/js/plugins/smooth-scrollbar.min.js"></script>

<!-- Github buttons -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../../assets/js/material-dashboard.min.js?v=3.1.0"></script>
</body>
</html>