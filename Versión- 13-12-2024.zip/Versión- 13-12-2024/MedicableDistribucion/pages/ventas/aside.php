<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />

<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header">
      <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
      <a class="navbar-brand m-0" href="https://medicable.com.mx" target="_blank">
        <img src="../logo-blanco.png" class="navbar-brand-img h-100" alt="main_logo">
        
      </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse w-auto" id="sidenav-collapse-main">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link text-white" href="../dashboard.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">dashboard</i>
            </div>
            <span class="nav-link-text ms-1">Dashboard</span>
          </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#ventas-dropdown" aria-controls="ventas-dropdown" aria-expanded="false" aria-label="Ventas">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                <i class="material-icons opacity-10">table_view</i>
                </div>
                <span class="nav-link-text ms-1">Ventas</span>
            </a>
            <div class="collapse show" id="ventas-dropdown">
                <ul class="navbar-nav">
                <li>
                    <a class="nav-link text-white" href="NuevaOT.php">
                    <span class="nav-link-text ms-1">Nueva OT</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link text-white active bg-gradient-primary"  href="OrdenTrabajo.php">
                    <span class="nav-link-text ms-1">Crear Orden de Trabajo</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link text-white" href="OrdenesTrabajo.php">
                    <span class="nav-link-text ms-1">Ordenes de Trabajo</span>
                    </a>
                </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="../logistica/OrdenDistribucion.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">receipt_long</i>
            </div>
            <span class="nav-link-text ms-1">Logistica</span>
          </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#almacen-dropdown" aria-controls="almacen-dropdown" aria-expanded="false" aria-label="Almacen">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                    <i class="material-icons opacity-10">view_in_ar</i>
                </div>
                <span class="nav-link-text ms-1">Almacen</span>
            </a>
            <div class="collapse" id="almacen-dropdown">
                <ul class="navbar-nav">
                    <li>
                        <a class="nav-link text-white" href="../almacen/Bodega.php">
                            <span class="nav-link-text ms-1">Bodega: Recepción</span>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link text-white" href="../almacen/instrucciones.php">
                            <span class="nav-link-text ms-1">Armados: Instrucciones</span>
                        </a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
                <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#vehiculos-dropdown" aria-controls="vehiculos-dropdown" aria-expanded="false" aria-label="Vehiculos">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">format_textdirection_r_to_l</i>
                    </div>
                    <span class="nav-link-text ms-1">Vehiculos</span>
                </a>
                <div class="collapse" id="vehiculos-dropdown">
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white" href="../vehiculos/calendario.php">
                                <span class="nav-link-text ms-1">Calendario</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="../pages/notifications.html">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">notifications</i>
            </div>
            <span class="nav-link-text ms-1">Usuarios</span>
          </a>
        </li>
      </ul>
    </div>
    <div class="sidenav-footer position-absolute w-100 bottom-0">
      <div class="mx-3">
        <a class="btn bg-gradient-primary w-100" href="https://www.medicable.com.mx" type="button">Cerrar Sesión</a>
      </div>
    </div>
</aside>