<?php
// Configuración de la base de datos
$host = 'localhost'; // Cambia esto si tu servidor de base de datos está en otro lugar
$user = 'root'; // Cambia esto por tu usuario de base de datos
$password = ''; // Cambia esto por tu contraseña de base de datos
$dbname = 'controldistribucion'; // Cambia esto por el nombre de tu base de datos

// Crear conexión
$conn = new mysqli($host, $user, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Realizar la consulta para obtener el número de OT
$query = "SELECT numero_ot FROM `ordenes_trabajo` LIMIT 1";
$result = $conn->query($query);

// Inicializar la variable para el número de OT
$numero_ot = '';

// Verificar si se obtuvo un resultado
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $numero_ot = $row['numero_ot'];
} else {
    $numero_ot = ''; // Valor por defecto si no hay resultados
}

// Cerrar la conexión
$conn->close();

// Concatenar el prefijo "OT-" al número de OT
$numero_ot_con_prefijo = 'OT-' . htmlspecialchars($numero_ot);

// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $numero_ot = $numero_ot_con_prefijo;
    $ejecutivo = $_POST['ejecutivo'];
    $area = "Comercial"; // Valor fijo según tu formulario
    $fecha_llenado = $_POST['fechaLlenado'];
    $nombre_empresa = $_POST['nombreEmpresa'];
    $nombre_contacto = $_POST['nombreContacto'];
    $puesto_contacto = $_POST['puestoContacto'];
    $correo = $_POST['correo'];
    $marca = $_POST['marca'];
    $fecha_inicio = $_POST['fechaInicio'];
    $fecha_fin = $_POST['fechaFin'];
    $cantidad = $_POST['cantidad']; // Aquí se captura la cantidad
    $paqueteentregar = $_POST['paqueteentregar']; // Captura el paquete a entregar
    $descripcion = $_POST['descripcion'];

    // Crear conexión nuevamente para insertar datos
    $conn = new mysqli($host, $user, $password, $dbname);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

   // Preparar la consulta de inserción
$stmt = $conn->prepare("INSERT INTO ot (numero_ot, ejecutivo, area, fecha_llenado, nombre_empresa, nombre_contacto, puesto_contacto, correo, marca, fecha_inicio, fecha_fin, cantidad, paqueteentregar, descripcion) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssssssssss", $numero_ot, $ejecutivo, $area, $fecha_llenado, $nombre_empresa, $nombre_contacto, $puesto_contacto, $correo, $marca, $fecha_inicio, $fecha_fin, $cantidad, $paqueteentregar, $descripcion);
    // Ejecutar la consulta
    if ($stmt->execute()) {
        // Redirigir a OT-2.php después de la inserción
        header("Location: OT-2.php");
        exit(); // Asegúrate de usar exit después de header
    } else {
        echo "Error: " . $stmt->error; // Muestra el error si ocurre
    }

    // Cerrar la declaración y la conexión
    $stmt->close();
    $conn->close();
} else {
    // Solo mostrar el formulario si no se ha enviado
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="../../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../../assets/img/favicon.png">
  <title>Medicable Control y Distribucion</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3. 0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href ="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
  <link href="../../assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="../../assets/css/nucleo-svg.css" rel="stylesheet" />
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <link id="pagestyle" href="../../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
<body class="g-sidenav-show bg-gray-200">
<?php include "aside.php" ?>

  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
   
    <div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
        <div class="card card-sm my-4">                
            <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                    <h6 class="text-white text-capitalize ps-3">NUEVA ORDEN DE TRABAJO</h6>
                </div>
                </div>
                <div class="container-fluid py-4 d-flex justify-content-center align-items-center" style="min-height: 75vh;">
                <div class="container">
        <form class="needs-validation" method="POST" action="" novalidate>
            <!-- Sección OT -->
            <fieldset class="mb-4">
                <div class="row mb-3">
                    <div class="col-md-3">
                        <label for="ot" class="form-label ">OT</label>
                        <input type="text" class="form-control" id="ot" placeholder="OT" value="<?php echo $numero_ot_con_prefijo; ?>" readonly>
                        <div class="invalid-feedback">Por favor, ingrese un OT válido.</div>
                    </div>
                    <div class="col-md-3">
                        <label for="ejecutivo" class="form-label">Ejecutivo</label>
                        <select class="form-select" id="ejecutivo" name="ejecutivo" required>
                            <option selected disabled value="">Seleccione un ejecutivo</option>
                            <option value="Arturo Pando">Arturo Pando</option>
                            <option value="Anina Dena">Anina Dena</option>
                            <option value="Aremi Riquelme">Aremi Riquelme</option>
                            <option value="Samuel Díaz">Samuel Díaz</option>
                            <option value="Vania Soto">Vania Soto</option>
                        </select>
                        <div class="invalid-feedback">Por favor, seleccione un ejecutivo.</div>
                    </div>
                    <div class="col-md-3">
                        <label for="area" class="form-label">Área</label>
                        <input type="text" class="form-control" id="area" value="Comercial" readonly>
                    </div>
                    <div class="col-md-3">
                        <label for="fechaLlenado" class="form-label">Fecha de Llenado</label>
                        <input type="date" class="form-control" id="fechaLlenado" name="fechaLlenado" required>
                        <div class="invalid-feedback">Por favor, seleccione una fecha.</div>
                    </div>
                </div>
            </fieldset>

            <!-- Sección Cliente -->
            <fieldset class="mb-4">
                <legend class="fw-bold">Información del Cliente</legend>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="nombreEmpresa" class="form-label">Nombre de la Empresa</label>
                        <input type="text" class="form-control" id="nombreEmpresa" name="nombreEmpresa" placeholder="Nombre de la Empresa" required>
                        <div class="invalid-feedback">Por favor, ingrese el nombre de la empresa.</div>
                    </div>
                    <div class="col-md-4">
                        <label for="nombreContacto" class="form-label">Nombre del Contacto</label>
                        <input type="text" class="form-control" id="nombreContacto" name="nombreContacto" placeholder="Nombre del Contacto" required>
                        <div class="invalid-feedback">Por favor, ingrese el nombre del contacto.</div>
                    </div>
                    <div class="col-md-4">
                        <label for="puestoContacto" class="form-label">Puesto del Contacto</label>
                        <input type="text" class="form-control" id="puestoContacto" name="puestoContacto" placeholder="Puesto del Contacto" required>
                        <div class="invalid-feedback">Por favor, ingrese el puesto del contacto.</div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="correo" class="form-label">Correo</label>
                        <input type="email" class="form-control" id="correo" name="correo" placeholder="Correo" required>
                        <div class="invalid-feedback">Por favor, ingrese un correo válido.</div>
                    </div>
                    <div class="col-md-4">
                        <label for="marca" class="form-label">Marca</label>
                        <input type="text" class="form-control" id="marca" name="marca" placeholder="Marca" required>
                        <div class="invalid-feedback">Por favor, ingrese la marca.</div>
                    </div>
                </div>
            </fieldset>
            <!-- Sección Campaña -->
            <fieldset class="mb-4">
                <legend class="fw-bold">Información de la Campaña</legend>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="fechaInicio" class="form-label">Fecha de Inicio</label>
                        <input type="date" class="form-control" id="fechaInicio" name="fechaInicio" required>
                        <div class="invalid-feedback">Por favor, seleccione una fecha de inicio.</div>
                    </div>
                    <div class="col-md-4">
                        <label for="fechaFin" class="form-label">Fecha de Fin</label>
                        <input type="date" class="form-control" id="fechaFin" name="fechaFin" required>
                        <div class="invalid-feedback">Por favor, seleccione una fecha de fin.</div>
                    </div>
                    <div class="col-md-4">
                        <label for="cantidad" class="form-label">Cantidad Total de paquetes a entregar</label>
                        <input type="text" class="form-control" id="cantidad" name="cantidad" placeholder="Cantidad Total" required>
                        <div class="invalid-feedback">Por favor, ingrese la cantidad total.</div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="paqueteentregar" class="form-label">Paquete a Entregar</label>
                        <input type="text" class="form-control" id="paqueteentregar" name="paqueteentregar" placeholder="Paquete a Entregar" required>
                        <div class="invalid-feedback">Por favor, ingrese el paquete a entregar.</div>
                    </div>
                </div>
            </fieldset>

            <div class="mb-3">
                <label for="descripcion" class="form-label">Objetivo</label>
                <textarea class="form-control" id="descripcion" name="descripcion" rows="3" required></textarea>
                <div class="invalid-feedback">Por favor, ingrese una descripción.</div>
            </div>
            <button type="submit" name="submit_type" value="Enviar1" class="btn btn-success">Enviar</button>
        </form>
    </div>
    <script>
        // Establecer límites para las fechas
        document.addEventListener('DOMContentLoaded', function () {
            const fechaLlenado = document.getElementById('fechaLlenado');
            const fechaInicio = document.getElementById('fechaInicio');
            const fechaFin = document.getElementById('fechaFin');

            // Establecer la fecha mínima para "Fecha de Llenado"
            const today = new Date().toISOString().split('T')[0];
            fechaLlenado.setAttribute('min', today);

            // Establecer la fecha mínima para "Fecha de Inicio" cuando se selecciona "Fecha de Llenado"
            fechaLlenado.addEventListener('change', function () {
                const selectedDate = new Date(fechaLlenado.value);
                selectedDate.setDate(selectedDate.getDate() + 1); // Sumar un día
 const minFechaInicio = selectedDate.toISOString().split('T')[0];
                fechaInicio.setAttribute('min', minFechaInicio);
                fechaInicio.value = ''; // Limpiar el campo de fecha de inicio
            });

            // Establecer la fecha mínima para "Fecha de Fin" cuando se selecciona "Fecha de Inicio"
            fechaInicio.addEventListener('change', function () {
                const selectedDate = new Date(fechaInicio.value);
                selectedDate.setDate(selectedDate.getDate() + 1); // Sumar un día
                const minFechaFin = selectedDate.toISOString().split('T')[0];
                fechaFin.setAttribute('min', minFechaFin);
                fechaFin.value = ''; // Limpiar el campo de fecha de fin
            });
        });

        // Ejemplo de JavaScript para la validación del formulario
        (function () {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        form.classList.add('was-validated')
                    }, false)
                })
        })()
    </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
                </div>
            </div>
        </div>
      </div>
      <footer class="footer py-4">
        <div class ="container-fluid">
          <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
              <div class="copyright text-center text-sm text-muted text-lg-start">
                © <script>
                  document.write (new Date().getFullYear())
                </script>,
                
                <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Medicable</a>
                Todos los derechos reservados.
              </div>
            </div>
      </div>
        </div>
      </footer>
    </div>
  </main>
  
  <!--   Core JS Files   -->
  <script src="../../assets/js/core/popper.min.js"></script>
  <script src="../../assets/js/core/bootstrap.min.js"></script>
  <script src="../../assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="../../assets/js/plugins/smooth-scrollbar.min.js"></script>
  
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../../assets/js/material-dashboard.min.js?v=3.1.0"></script>
</body>
</html>
<?php
}
?>