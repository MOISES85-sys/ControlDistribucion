<?php
session_start(); // Iniciar la sesión

// Configuración de la base de datos
$host = 'localhost'; // Cambia esto si tu servidor de base de datos está en otro lugar
$user = 'root'; // Cambia esto por tu usuario de base de datos
$password = ''; // Cambia esto por tu contraseña de base de datos
$dbname = 'controldistribucion'; // Cambia esto por el nombre de tu base de datos

// Crear conexión
$conn = new mysqli($host, $user, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel ="apple-touch-icon" sizes="76x76" href="../../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../../assets/img/favicon.png">
    <title>Medicable Control y Distribucion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <link href="../../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../../assets/css/nucleo-svg.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link id="pagestyle" href="../../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
</head>
<body class="g-sidenav-show bg-gray-200">
<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header">
      <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
      <a class="navbar-brand m-0" href="https://medicable.com.mx" target="_blank">
        <img src="../logo-blanco.png" class="navbar-brand-img h-100" alt="main_logo">
        
      </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse w-auto" id="sidenav-collapse-main">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link text-white" href="../dashboard.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">dashboard</i>
            </div>
            <span class="nav-link-text ms-1">Dashboard</span>
          </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#ventas-dropdown" aria-controls="ventas-dropdown" aria-expanded="false" aria-label="Ventas">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                <i class="material-icons opacity-10">table_view</i>
                </div>
                <span class="nav-link-text ms-1">Ventas</span>
            </a>
            <div class="collapse show" id="ventas-dropdown">
                <ul class="navbar-nav">
                <li>
                    <a class="nav-link text-white" href="NuevaOT.php">
                    <span class="nav-link-text ms-1">Nueva OT</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link text-white"  href="OrdenTrabajo.php">
                    <span class="nav-link-text ms-1">Crear Orden de Trabajo</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link text-white" href="OrdenesTrabajo.php">
                    <span class="nav-link-text ms-1">Ordenes de Trabajo</span>
                    </a>
                </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="../logistica/OrdenDistribucion.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">receipt_long</i>
            </div>
            <span class="nav-link-text ms-1">Logistica</span>
          </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#almacen-dropdown" aria-controls="almacen-dropdown" aria-expanded="false" aria-label="Almacen">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                    <i class="material-icons opacity-10">view_in_ar</i>
                </div>
                <span class="nav-link-text ms-1">Almacen</span>
            </a>
            <div class="collapse" id="almacen-dropdown">
                <ul class="navbar-nav">
                    <li>
                        <a class="nav-link text-white" href="../almacen/Bodega.php">
                            <span class="nav-link-text ms-1">Bodega: Recepción</span>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link text-white" href="../almacen/instrucciones.php">
                            <span class="nav-link-text ms-1">Armados: Instrucciones</span>
                        </a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
                <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#vehiculos-dropdown" aria-controls="vehiculos-dropdown" aria-expanded="false" aria-label="Vehiculos">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">format_textdirection_r_to_l</i>
                    </div>
                    <span class="nav-link-text ms-1">Vehiculos</span>
                </a>
                <div class="collapse" id="vehiculos-dropdown">
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white" href="../vehiculos/calendario.php">
                                <span class="nav-link-text ms-1">Calendario</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
        <li class="nav-item">
          <a class="nav-link text-white active bg-gradient-primary" href="usuarios.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">notifications</i>
            </div>
            <span class="nav-link-text ms-1">Usuarios</span>
          </a>
        </li>
      </ul>
    </div>
    <div class="sidenav-footer position-absolute w-100 bottom-0">
      <div class="mx-3">
        <a class="btn bg-gradient-primary w-100" href="https://www.medicable.com.mx" type="button">Cerrar Sesión</a>
      </div>
    </div>
</aside>
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card card-sm my-4">
                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-white text-capitalize ps-3">CONTROL DE USUARIOS</h6>
                        </div>
                    </div>
                    <div class="container-fluid py-4 d-flex justify-content-center align-items-center" style="min-height: 75vh;">
                        <div class="container">
                            
                        </div>  
                    </div>
                </div>
            </div>
            <footer class="footer py-4">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-lg-between">
                        <div class="col-lg-6 mb-lg-0 mb-4">
                            <div class="copyright text-center text-sm text-muted text-lg-start">
                                © <script>
                                    document.write(new Date().getFullYear())
                                </script>,
                                <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Medicable</a>
                                Todos los derechos reservados.
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </main>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    
</body>
</html>