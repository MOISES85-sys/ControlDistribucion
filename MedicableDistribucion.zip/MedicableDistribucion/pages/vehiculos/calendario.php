<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$database = "controldistribucion";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Insertar nuevo registro
if (isset($_POST['submit'])) {
    $fecha = $_POST['fecha'];
    $idzonaseccion = $_POST['idzonaseccion'];
    $id_vehiculo = $_POST['id_vehiculo'];

    $sql = "INSERT INTO vehiculodia (fecha, idzonaseccion, id_vehiculo) 
            VALUES ('$fecha', '$idzonaseccion', '$id_vehiculo')";
    if ($conn->query($sql) === TRUE) {
        echo "Nuevo registro creado exitosamente.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Actualizar registro
if (isset($_POST['update'])) {
    $idDia = $_POST['idDia'];
    $fecha = $_POST['fecha'];
    $idzonaseccion = $_POST['idzonaseccion'];
    $id_vehiculo = $_POST['id_vehiculo'];

    $sql = "UPDATE vehiculodia SET 
            fecha='$fecha', idzonaseccion='$idzonaseccion', id_vehiculo='$id_vehiculo' 
            WHERE idDia='$idDia'";
    if ($conn->query($sql) === TRUE) {
        echo "Registro actualizado exitosamente.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Eliminar registro
if (isset($_GET['delete'])) {
    $idDia = $_GET['delete'];
    $sql = "DELETE FROM vehiculodia WHERE idDia='$idDia'";
    if ($conn->query($sql) === TRUE) {
        echo "Registro eliminado exitosamente.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Obtener todos los registros de vehiculodia y sus respectivas zonas y secciones
$sql = "SELECT v.*, z.Zona, z.Seccion, ve.modelo, ve.placas 
        FROM vehiculodia v 
        JOIN zonaseccion z ON v.idzonaseccion = z.idzonaseccion 
        JOIN vehiculos ve ON v.id_vehiculo = ve.id_vehiculo";
$result = $conn->query($sql);

// Obtener todas las zonas y secciones para el modal
$sql_zonaseccion = "SELECT idzonaseccion, Zona, Seccion FROM zonaseccion";
$result_zonaseccion = $conn->query($sql_zonaseccion);

// Obtener todos los vehículos para el modal
$sql_vehiculos = "SELECT id_vehiculo, modelo, placas FROM vehiculos";
$result_vehiculos = $conn->query($sql_vehiculos);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" href="../../assets/img/favicon.png">
    <title>Medicable Control y Distribucion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <link href="../../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../../assets/css/nucleo-svg.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link id="pagestyle" href="../../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
</head>
<body class="g-sidenav-show bg-gray-200">
<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand m-0" href="https://demos.creative-tim.com/material-dashboard/pages/dashboard" target="_blank">
            <img src="../../assets/img/logo-ct.png" class="navbar-brand-img h-100" alt="main_logo">
            <span class="ms-1 font-weight-bold text-white">Medicable</span>
        </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse w-auto" id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link text-white" href="../dashboard.php">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">dashboard</i>
                    </div>
                    <span class="nav-link-text ms-1">Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#ventas-dropdown" aria-controls="ventas-dropdown" aria-expanded="false" aria-label="Ventas">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">table_view</i>
                    </div>
                    <span class="nav-link-text ms-1">Ventas</span>
                </a>
                <div class="collapse show" id="ventas-dropdown">
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white" href="../ventas/NuevaOT.php">
                                <span class="nav-link-text ms-1">Nueva OT</span>
                            </a>
                        </li>
                        <li>
                            <a class="nav-link text-white" href="../ventas/OrdenTrabajo.php">
                                <span class="nav-link-text ms-1">Crear Orden de Trabajo</span>
                            </a>
                        </li>
                        <li>
                            <a class="nav-link text-white" href="../ventas/OrdenesTrabajo.php">
                                <span class="nav-link-text ms-1">Ordenes de Trabajo</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../logistica/OrdenDistribucion.php">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">receipt_long</i>
                    </div>
                    <span class="nav-link-text ms-1">Logistica</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../../pages/virtual-reality.html">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">view_in_ar </i>
                    </div>
                    <span class="nav-link-text ms-1">Almacen</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#vehiculos-dropdown" aria-controls="vehiculos-dropdown" aria-expanded="false" aria-label="Vehiculos">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">format_textdirection_r_to_l</i>
                    </div>
                    <span class="nav-link-text ms-1">Vehiculos</span>
                </a>
                <div class="collapse" id="vehiculos-dropdown">
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white active bg-gradient-primary" href="calendario.php">
                                <span class="nav-link-text ms-1">Calendario</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../pages/notifications.html">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">notifications</i>
                    </div>
                    <span class="nav-link-text ms-1">Usuarios</span>
                </a>
            </li>
        </ul>
    </div>
    <div class="sidenav-footer position-absolute w-100 bottom-0">
        <div class="mx-3">
            <a class="btn bg-gradient-primary w-100" href="https ://www.creative-tim.com/product/material-dashboard-pro?ref=sidebarfree" type="button">Cerrar Sesión</a>
        </div>
    </div>
</aside>

<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card card-sm my-4">
                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-white text-capitalize ps-3">Control de Vehiculos</h6>
                        </div>
                    </div>
                    <div class="container-fluid py-4 d-flex justify-content-center align-items-center" style="min-height: 75vh;">
                        <div class="container my-4">
                            <h1 class="text-center mb-4">Asignación de Zona Sección</h1>

                            <!-- Botón para abrir el modal de registro -->
                            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addModal">Agregar Fecha</button>

                            <!-- Tabla de datos -->
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Fecha</th>
                                            <th>Zona</th>
                                            <th>Sección</th>
                                            <th>Modelo</th>
                                            <th>Placas</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = $result->fetch_assoc()): ?>
                                            <tr>
                                                <td><?= $row['fecha'] ?></td>
                                                <td><?= $row['Zona'] ?></td>
                                                <td><?= $row['Seccion'] ?></td>
                                                <td><?= $row['modelo'] ?></td>
                                                <td><?= $row['placas'] ?></td>
                                                <td>
                                                    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editModal"
                                                            data-id="<?= $row['idDia'] ?>"
                                                            data-fecha="<?= $row['fecha'] ?>"
                                                            data-idzonaseccion="<?= $row['idzonaseccion'] ?>"
                                                            data-id_vehiculo="<?= $row['id_vehiculo'] ?>">Editar
                                                    </button>
                                                    <a href="?delete=<?= $row['idDia'] ?>" class="btn btn-danger btn-sm">Borrar</a>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Modal para agregar fecha -->
                            <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="post" action="">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="addModalLabel">Agregar Fecha</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="fecha" class="form-label">Fecha</label>
                                                    <input type="date" class="form-control" id="fecha" name="fecha" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="idzonaseccion" class="form-label">Zona Sección</label>
                                                    <select class="form-control" id="idzonaseccion" name="idzonaseccion" required>
                                                        <?php while ($zona_seccion = $result_zonaseccion->fetch_assoc()): ?>
                                                            <option value="<?= $zona_seccion['idzonaseccion'] ?>"><?= $zona_seccion['Zona'] . ' - ' . $zona_seccion['Seccion'] ?></option>
                                                        <?php endwhile; ?>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="id_vehiculo" class="form-label">Vehículo</label>
                                                    <select class="form-control" id="id_vehiculo" name="id_vehiculo" required>
                                                        <?php while ($vehiculo = $result_vehiculos->fetch_assoc()): ?>
                                                            <option value="<?= $vehiculo['id_vehiculo'] ?>"><?= $vehiculo['modelo'] . ' - ' . $vehiculo['placas'] ?></option>
                                                        <?php endwhile; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                                <button type="submit" name="submit" class="btn btn-primary">Agregar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal para editar vehículo día -->
                            <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="post" action="">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editModalLabel">Editar Vehículo Día</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <input type="hidden" id="edit_idDia" name="idDia">
                                                <div class="mb-3">
                                                    <label for="edit_fecha" class="form-label">Fecha</label>
                                                    <input type="date" class="form-control" id="edit_fecha" name="fecha" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="edit_idzonaseccion" class="form-label">Zona Sección</label>
                                                    <select class="form-control" id="edit_idzonaseccion" name="idzonaseccion" required>
                                                        <?php
                                                        // Reiniciar el puntero del resultado para el modal de edición
                                                        $result_zonaseccion->data_seek(0);
                                                        while ($zona_seccion = $result_zonaseccion->fetch_assoc()): ?>
                                                            <option value="<?= $zona_seccion['idzonaseccion'] ?>"><?= $zona_seccion['Zona'] . ' - ' . $zona_seccion['Seccion'] ?></option>
                                                        <?php endwhile; ?>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="edit_id_vehiculo" class="form-label">Vehículo</label>
                                                    <select class="form-control" id="edit_id_vehiculo" name="id_vehiculo" required>
                                                        <?php
                                                        // Reiniciar el puntero del resultado para los vehículos
                                                        $result_vehiculos->data_seek(0);
                                                        while ($vehiculo = $result_vehiculos->fetch_assoc()): ?>
                                                            <option value="<?= $vehiculo['id_vehiculo'] ?>"><?= $vehiculo['modelo'] . ' - ' . $vehiculo['placas'] ?></option>
                                                        <?php endwhile; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                                <button type="submit" name="update" class="btn btn-primary">Guardar Cambios</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <script>
                                // Llenar el modal de edición con los datos del vehículo día seleccionado
                                const editModal = document.getElementById('editModal');
                                editModal.addEventListener('show.bs.modal', function (event) {
                                    const button = event.relatedTarget;
                                    document.getElementById('edit_idDia').value = button.getAttribute('data-id');
                                    document.getElementById('edit_fecha').value = button.getAttribute('data-fecha');
                                    document.getElementById('edit_idzonaseccion').value = button.getAttribute('data-idzonaseccion');
                                    document.getElementById('edit_id_vehiculo').value = button.getAttribute('data-id_vehiculo');
                                });
                            </script>
                            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
                        </div>
                    </div>
                    <footer class="footer py-4">
                        <div class="container-fluid">
                            <div class="row align-items-center justify-content-lg-between">
                                <div class="col-lg-6 mb-lg-0 mb-4">
                                    <div class="copyright text-center text-sm text-muted text-lg-start">
                                        © <script>
                                            document.write(new Date().getFullYear())
                                        </script>,
                                        <i class="fa fa-heart"></i>
                                        <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank ">Medicable</a>
                                        Todos los derechos reservados.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </footer>
                </div>
            </div>
        </div>
    </div>
</main>
<!--Core JS Files-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="../../assets/js/core/popper.min.js"></script>
<script src="../../assets/js/core/bootstrap.min.js"></script>
<script src="../../assets/js/plugins/perfect-scrollbar.min.js"></script>
<script src="../../assets/js/plugins/smooth-scrollbar.min.js"></script>

<!-- Github buttons -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../../assets/js/material-dashboard.min.js?v=3.1.0"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>