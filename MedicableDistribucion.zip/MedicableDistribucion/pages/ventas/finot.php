<?php
session_start(); // Iniciar la sesión

// Configuración de la base de datos
$host = 'localhost'; // Cambia esto si tu servidor de base de datos está en otro lugar
$user = 'root'; // Cambia esto por tu usuario de base de datos
$password = ''; // Cambia esto por tu contraseña de base de datos
$dbname = 'controldistribucion'; // Cambia esto por el nombre de tu base de datos

// Crear conexión
$conn = new mysqli($host, $user, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Realiza la consulta para obtener la última orden de trabajo
$sql = "SELECT * FROM ot ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

// Inicializa la variable para mostrar los datos
$ordenTrabajo = null;

if ($result->num_rows > 0) {
    // Obtén la última orden de trabajo
    $ordenTrabajo = $result->fetch_assoc();
} else {
    $ordenTrabajo = "Sin resultados";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel ="apple-touch-icon" sizes="76x76" href="../../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../../assets/img/favicon.png">
    <title>Medicable Control y Distribucion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <link href="../../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../../assets/css/nucleo-svg.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link id="pagestyle" href="../../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
</head>
<body class="g-sidenav-show bg-gray-200">
<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header">
      <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
      <a class="navbar-brand m-0" href="https://demos.creative-tim.com/material-dashboard/pages/dashboard" target="_blank">
        <img src="../../assets/img/logo-ct.png" class="navbar-brand-img h-100" alt="main_logo">
        <span class="ms-1 font-weight-bold text-white">Medicable</span>
      </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse w-auto" id="sidenav-collapse-main">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link text-white" href="../dashboard.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">dashboard</i>
            </div>
            <span class="nav-link-text ms-1">Dashboard</span>
          </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#ventas-dropdown" aria-controls="ventas-dropdown" aria-expanded="false" aria-label="Ventas">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                <i class="material-icons opacity-10">table_view</i>
                </div>
                <span class="nav-link-text ms-1">Ventas</span>
            </a>
            <div class="collapse show" id="ventas-dropdown">
                <ul class="navbar-nav">
                <li>
                    <a class="nav-link text-white active bg-gradient-primary" href="NuevaOT.php">
                    <span class="nav-link-text ms-1">Nueva OT</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link text-white" href="OrdenTrabajo.php">
                    <span class="nav-link-text ms-1">Crear Orden de Trabajo</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link text-white" href="OrdenesTrabajo.php">
                    <span class="nav-link-text ms-1">Ordenes de Trabajo</span>
                    </a>
                </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="../logistica/OrdenDistribucion.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">receipt_long</i>
            </div>
            <span class="nav-link-text ms-1">Logistica</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="../almacen/">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">view_in_ar</i>
            </div>
            <span class="nav-link-text ms-1">Almacen</span>
          </a>
        </li>
        <li class="nav-item">
                <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#vehiculos-dropdown" aria-controls="vehiculos-dropdown" aria-expanded="false" aria-label="Vehiculos">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">format_textdirection_r_to_l</i>
                    </div>
                    <span class="nav-link-text ms-1">Vehiculos</span>
                </a>
                <div class="collapse" id="vehiculos-dropdown">
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white" href="../vehiculos/calendario.php">
                                <span class="nav-link-text ms-1">Calendario</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="../pages/notifications.html">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">notifications</i>
            </div>
            <span class="nav-link-text ms-1">Usuarios</span>
          </a>
        </li>
      </ul>
    </div>
    <div class="sidenav-footer position-absolute w-100 bottom-0">
      <div class="mx-3">
        <a class="btn bg-gradient-primary w-100" href="https://www.creative-tim.com/product/material-dashboard-pro?ref=sidebarfree" type="button">Cerrar Sesión</a>
      </div>
    </div>
</aside>
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card card-sm my-4">
                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-white text-capitalize ps-3">IMPRIMIR ORDEN DE TRABAJO</h6>
                        </div>
                    </div>
                    <div class="container-fluid py-4 d-flex justify-content-center align-items-center" style="min-height: 75vh;">
                        <div class="container">
                            <h3 class="text-center text-primary mb-4">
                                Número: <?php echo htmlspecialchars($ordenTrabajo['numero_ot'] ?? 'Sin resultados'); ?>
                            </h3>
                            <p class="text-center mb-4">¡Orden de trabajo creada exitosamente!</p>
                            <div class="text-center">
                                <button type="button" class="btn btn-primary btn-lg mt-4" data-toggle="modal" data-target="#myModal">
                                    Imprimir Orden de Trabajo
                                </button>
                            </div>
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content border-0 shadow-lg">
                                        <div class="modal-header bg-primary text-white">
                                            <h5 class="modal-title" id="exampleModalLabel">Confirmación</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times </span>
                                            </button>
                                        </div>
                                        <div class="modal-body p-5">
                                            <h4 class="text-center mb-4">¿Quieres imprimir la orden de trabajo?</h4>
                                            <p class="text-muted text-center">Por favor, confirma que deseas imprimir la orden de trabajo.</p>
                                        </div>
                                        <div class="modal-footer justify-content-between">
                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                                            <button type="button" class="btn btn-success" onclick="imprimirOrden()">Imprimir</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>  
                    </div>
                </div>
            </div>
            <footer class="footer py-4">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-lg-between">
                        <div class="col-lg-6 mb-lg-0 mb-4">
                            <div class="copyright text-center text-sm text-muted text-lg-start">
                                © <script>
                                    document.write(new Date().getFullYear())
                                </script>,
                                <i class="fa fa-heart"></i>
                                <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Medicable</a>
                                Todos los derechos reservados.
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </main>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script>
        function imprimirOrden() {
            const ordenTrabajo = <?php echo json_encode($ordenTrabajo); ?>;
            let contenido = `
                <html>
                <head>
                    <title>Imprimir Orden de Trabajo</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            margin: 20px;
                        }
                        table {
                            width: 100%;
                            border-collapse: collapse;
                            margin-top: 20px;
                        }
                        th, td {
                            border: 1px solid #000;
                            padding: 10px;
                            text-align: left;
                        }
                        th {
                            background-color: #f2f2f2;
                        }
                        .logo {
                            width: 100px; /* Ajusta el tamaño del logo */
                        }
                        .header {
                            display: flex;
                            align-items: center;
                        }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <img src="../logo-blanco.png" class="logo" alt="Logo"> <!-- Cambia la ruta a tu logo -->
                        <h1 style="margin-left: 20px;">Orden de Trabajo</h1>
                    </div>
                    <table>
                        <tr>
                            <th>Número OT</th>
                            <td>${ordenTrabajo.numero_ot}</td>
                        </tr>
                        <tr>
                            <th>Ejecutivo</th>
                            <td>${ordenTrabajo.ejecutivo}</td>
                        </tr>
                        <tr>
                            <th>Área</th>
                            <td>${ordenTrabajo.area}</td>
                        </tr>
                        <tr>
                            <th>Fecha de llenado</th>
                            <td>${ordenTrabajo.fecha_llenado}</td>
                        </tr>
                        <tr>
                            <th>Nombre de la empresa</th>
                            <td>${ordenTrabajo.nombre_empresa}</td>
                        </tr>
                        <tr>
                            <th>Nombre de contacto</th>
                            <td>${ordenTrabajo.nombre_contacto}</td>
                        </tr>
                        <tr>
                            <th>Puesto de contacto</th>
                            <td>${ordenTrabajo.puesto_contacto}</td>
                        </tr>
                        <tr>
                            <th>Correo</th>
                            <td>${ordenTrabajo.correo}</td>
                        </tr>
                        <tr>
                            <th>Marca</th>
                            <td>${ordenTrabajo.marca}</td>
                        </tr>
                        <tr>
                            <th>Fecha de inicio</th>
                            <td>${ordenTrabajo.fecha_inicio}</td>
                        </tr>
                        <tr>
                            <th>Fecha de fin</th>
                            <td>${ordenTrabajo.fecha_fin}</td>
                        </tr>
                        <tr>
                            <th>Cantidad</th>
                            <td>${ordenTrabajo.cantidad}</td </tr>
                        <tr>
                            <th>Descripción</th>
                            <td>${ordenTrabajo.descripcion}</td>
                        </tr>
                    </table>
                </body>
                </html>
            `;
            const ventanaImpresion = window.open('', '', 'height=600,width=800');
            ventanaImpresion.document.write(contenido);
            ventanaImpresion.document.close();
            ventanaImpresion.print();
        }
    </script>
</body>
</html>