<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "controldistribucion";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obtener especialidades médicas
$especialidades = [];
$sql = "SELECT nombre FROM especialidades_medicas";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $especialidades[] = $row['nombre'];
    }
}

// Manejar la solicitud POST para guardar los datos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    foreach ($data as $shot) {
        $ot = $shot['ot'];
        $numero_shot = $shot['numero_shot'];
        $fecha_inicial = $shot['fecha_inicial'];
        $fecha_final = $shot['fecha_final'];
        $especialidad = $shot['especialidad'];
        $cdmx = $shot['cdmx'];
        $tol = $shot['tol'];
        $qro = $shot['qro'];
        $pue = $shot['pue'];
        $gdl = $shot['gdl'];
        $mty = $shot['mty'];

        $sql = "INSERT INTO shot (OT, NUMERO_SHOT, FECHA_INICIAL, FECHA_FINAL, ESPECIALIDAD, CDMX, TOL, QRO, PUE, GDL, MTY) 
                VALUES ('$ot', '$numero_shot', '$fecha_inicial', '$fecha_final', '$especialidad', '$cdmx', '$tol', '$qro', '$pue', '$gdl', '$mty')";

        if (!$conn->query($sql)) {
            echo json_encode(['error' => $conn->error]);
            exit;
        }
    }
    echo json_encode(['success' => true]);
    exit;
}

// Obtener el último numero_ot
$sql = "SELECT numero_ot FROM paquete ORDER BY id_paquete DESC LIMIT 1";
$result = $conn->query($sql);
$numero_ot = $result->num_rows > 0 ? $result->fetch_assoc()['numero_ot'] : null;

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Distribuir Shots</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel ="apple-touch-icon" sizes="76x76" href="../../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../../assets/img/favicon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <link href="../../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../../assets/css/nucleo-svg.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link id="pagestyle" href="../../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet"/>
    <style>
        .card { box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); border-radius: 8px; overflow: hidden; }
        .card-header { background: linear-gradient(45deg, #007bff, #0056b3); color: white; font-weight: bold; text-align: center; }
        .card-body { background-color: #f9f9f9; }
        .btn-primary { background-color: #0056b3; border-color: #0056b3; }
        .btn-primary:hover { background-color: #003d80; border-color: #003d80; }
        .btn-success { font-size: 1.2rem; padding: 10px 20px; }
    </style>
</head>
<body class="g-sidenav-show bg-gray-200">
<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header">
      <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
      <a class="navbar-brand m-0" href="https://demos.creative-tim.com/material-dashboard/pages/dashboard" target="_blank">
        <img src="../../assets/img/logo-ct.png" class="navbar-brand-img h-100" alt="main_logo">
        <span class="ms-1 font-weight-bold text-white">Medicable</span>
      </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse w-auto" id="sidenav-collapse-main">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link text-white" href="../dashboard.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">dashboard</i>
            </div>
            <span class="nav-link-text ms-1">Dashboard</span>
          </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#ventas-dropdown" aria-controls="ventas-dropdown" aria-expanded="false" aria-label="Ventas">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                <i class="material-icons opacity-10">table_view</i>
                </div>
                <span class="nav-link-text ms-1">Ventas</span>
            </a>
 <div class="collapse show" id="ventas-dropdown">
                    <ul class="navbar-nav">
                        <li>
                            <a class="nav-link text-white" href="NuevaOT.php">
                                <span class="nav-link-text ms-1">Nueva OT</span>
                            </a>
                        </li>
                        <li>
                            <a class="nav-link text-white active bg-gradient-primary" href="OrdenTrabajo.php">
                                <span class="nav-link-text ms-1">Crear Orden de Trabajo</span>
                            </a>
                        </li>
                        <li>
                            <a class="nav-link text-white" href="OrdenesTrabajo.php">
                                <span class="nav-link-text ms-1">Ordenes de Trabajo</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../logistica/OrdenDistribucion.php">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">receipt_long</i>
                    </div>
                    <span class="nav-link-text ms-1">Logistica</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../../pages/virtual-reality.html">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">view_in_ar</i>
                    </div>
                    <span class="nav-link-text ms-1">Almacen</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../vehiculos/Vehiculos.php">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">format_textdirection_r_to_l</i>
                    </div>
                    <span class="nav-link-text ms-1">Vehiculos</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="../pages/notifications.html">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">notifications</i>
                    </div>
                    <span class="nav-link-text ms-1">Usuarios</span>
                </a>
            </li>
        </ul>
    </div>
    <div class="sidenav-footer position-absolute w-100 bottom-0">
        <div class="mx-3">
            <a class="btn bg-gradient-primary w-100" href="https://www.creative-tim.com/product/material-dashboard-pro?ref=sidebarfree" type="button">Cerrar Sesión</a>
        </div>
    </div>
</aside>

<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card card-sm my-4">
                     <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-white text-capitalize ps-3">SHOTS Y ESPECIALIDADES: CONTROL Y DISTRIBUCIÓN</h6>
                        </div>
                    </div>
                    <div class="container-fluid py-4 d-flex justify-content-center align-items-center" style="min-height: 75vh;">
                        <div class="container">
                            <div class="container my-5">
                                <div class="modal fade" id="tableModal" tabindex="-1" aria-labelledby="tableModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="tableModalLabel">Distribuir Shots</h5>
                                            </div>
                                            <div class="modal-body">
                                                <label for="tableCount" class="form-label">¿Cuántos shots deseas generar?</label>
                                                <input type="number" id="tableCount" class="form-control" placeholder="Cantidad de shots" min="1">
                                            </div>
                                            <div class="modal-footer">
                                                <button id="generateTables" class="btn btn-primary">Generar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="tableContainer"></div>

                                <div class="d-flex justify-content-end mt-4">
                                    <button id="sendButton" class="btn btn-success">Enviar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="footer py-4">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-lg-between">
                        <div class="col-lg-6 mb-lg-0 mb-4">
                            <div class="copyright text-center text-sm text-muted text-lg-start">
                                © <script>
                                    document.write(new Date().getFullYear())
                                </script>,
                                <i class="fa fa-heart"></i>
                                <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Medicable</a>
                                Todos los derechos reservados.
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            </div>
        </div>
    </div>
</main> 

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const tableModal = new bootstrap.Modal(document.getElementById('tableModal'));
    const especialidades = <?php echo json_encode($especialidades); ?>; // Pasar las especialidades a JavaScript

    window.onload = () => {
        tableModal.show(); // Mostrar el modal al cargar la página
    };

    document.getElementById('generateTables').addEventListener('click', () => {
        const tableCount = parseInt(document.getElementById('tableCount').value);
        const tableContainer = document.getElementById('tableContainer');

        if (!tableCount || tableCount < 1) {
            alert('Por favor, ingresa una cantidad válida de shots.');
            return;
        }

        // Limpiar el contenedor y generar shots
        tableContainer.innerHTML = '';
        for (let i = 0; i < tableCount; i++) {
            createShotCard(i + 1, tableContainer);
        }

        // Ocultar el modal después de generar los shots
        tableModal.hide();
    });

    function createShotCard(shotIndex, container) {
        const section = document.createElement('div');
        
        section.className = 'card mb-4';

        // Header de la tarjeta
        const cardHeader = document.createElement('div');
        cardHeader.className = 'card-header';
        cardHeader.textContent = `SHOT ${shotIndex}`;
        section.appendChild(cardHeader);

        // Cuerpo de la tarjeta
        const cardBody = document.createElement('div');
        cardBody.className = 'card-body';

        // Inputs de fecha inicial y final
        const dateInputs = document.createElement('div');
        dateInputs.className = 'd-flex mb-3 gap-3';

        const startDateLabel = document.createElement('label');
        startDateLabel.className = 'form-label';
        startDateLabel.innerHTML = 'Fecha Inicial:';
        const startDateInput = document.createElement('input');
        startDateInput.type = 'date';
        startDateInput.className = 'form-control';

        const endDateLabel = document.createElement('label');
        endDateLabel.className = 'form-label';
        endDateLabel.innerHTML = 'Fecha Final:';
        const endDateInput = document.createElement('input');
        endDateInput.type = 'date';
        endDateInput.className = 'form-control';

        dateInputs.appendChild(startDateLabel);
        dateInputs.appendChild(startDateInput);
        dateInputs.appendChild(endDateLabel);
        dateInputs.appendChild(endDateInput);
        cardBody.appendChild(dateInputs);

        // Botón de agregar especialidad
        const addRowButton = document.createElement('button');
        addRowButton.className = 'btn btn-primary mb-3';
        addRowButton.textContent = `Agregar Especialidad a SHOT ${shotIndex}`;
        cardBody.appendChild(addRowButton);

        // Tabla dinámica
        const table = document.createElement('table');
        table.className = 'table table-bordered text-center';
        table.innerHTML = `
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Especialidad</th>
                    <th>CDMX</th>
                    <th>TOL</th>
                    <th>PUE</th>
                    <th>QRO</th>
                    <th>GDL</th>
                    <th>MTY</th>
                    <th>Total</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;
        cardBody.appendChild(table);

        // Agregar filas a la tabla
        let rowCount = 1; // Contador para las filas
        addRowButton.addEventListener('click', () => {
            const tableBody = table.querySelector('tbody');
            const newRow = document.createElement('tr');

            // Número de fila
            const rowNumberCell = document.createElement('td');
            rowNumberCell.textContent = rowCount;
            newRow.appendChild(rowNumberCell);

            // Especialidad
            const specialtyCell = document.createElement('td');
            const specialtySelect = document.createElement('select');
            specialtySelect.className = 'form-select';
            especialidades.forEach(specialty => {
                const option = document.createElement('option');
                option.value = specialty;
                option.textContent = specialty;
                specialtySelect.appendChild(option);
            });
            specialtyCell.appendChild(specialtySelect);
            newRow.appendChild(specialtyCell);

            // Inputs de ciudades
            ['CDMX', 'TOL', 'PUE', 'QRO', 'GDL', 'MTY'].forEach(city => {
                const cityCell = document.createElement('td');
                const cityInput = document.createElement('input');
                cityInput.type = 'number';
                cityInput.className = 'form-control text-center';
                cityInput.value = 0;

                // Recalcular total al cambiar valores
                cityInput.addEventListener('input', updateRowTotal);
                cityCell.appendChild(cityInput);
                newRow.appendChild(cityCell);
            });

            // Celda de total
            const totalCell = document.createElement('td');
            const totalInput = document.createElement('input');
            totalInput.type = 'number';
            totalInput.className = 'form-control text-center';
            totalInput.value = 0;
            totalInput.readOnly = true;
            totalCell.appendChild(totalInput);
            newRow.appendChild(totalCell);

            // Botón de eliminar
            const actionCell = document.createElement('td');
            const deleteButton = document.createElement('button');
            deleteButton.className = 'btn btn-danger btn-sm';
            deleteButton.textContent = 'Eliminar';
            deleteButton.addEventListener('click', () => {
                newRow.remove();
                updateRowNumbers(); // Actualizar números de fila después de eliminar
            });
            actionCell.appendChild(deleteButton);
            newRow.appendChild(actionCell);

            tableBody.appendChild(newRow);

            // Actualizar el número de la fila para la siguiente
            rowCount++;

            // Función para actualizar el total en tiempo real
            function updateRowTotal() {
                const values = Array.from(newRow.querySelectorAll('td input[type="number"]'))
                    .slice(0, 6) // Solo inputs de las ciudades
                    .map(input => parseInt(input.value) || 0);
                totalInput.value = values.reduce((sum, val) => sum + val, 0);
            }

            // Función para actualizar los números de fila después de eliminar
            function updateRowNumbers() {
                const rows = table.querySelectorAll('tbody tr');
                rows.forEach((row, index) => {
                    row.querySelector('td').textContent = index + 1; // Actualizar el número de fila
                });
            }
        });

        section.appendChild(cardBody);
        container.appendChild(section);
    }

    document.getElementById('sendButton').addEventListener('click', async () => {
        const shots = [];
        const shotCards = document.querySelectorAll('#tableContainer .card');

        for (const card of shotCards) {
            const shotIndex = card.querySelector('.card-header').textContent.split(' ')[1];
            const startDate = card.querySelector('input[type="date"]:nth-of-type(1)').value;
            const endDate = card.querySelector('input[type="date"]:nth-of-type(2)').value;
            const specialties = card.querySelectorAll('tbody tr');

            for (const specialtyRow of specialties) {
                const specialty = specialtyRow.querySelector('select').value;
                const cityValues = Array.from(specialtyRow.querySelectorAll('input[type="number"]')).map(input => parseInt(input.value) || 0);
                const [cdmx, tol, qro, pue, gdl, mty] = cityValues;

                shots.push({
                    ot: <?php echo json_encode($numero_ot); ?>,
                    numero_shot: shotIndex,
                    fecha_inicial: startDate,
                    fecha_final: endDate,
                    especialidad: specialty,
                    cdmx,
                    tol,
                    qro,
                    pue,
                    gdl,
                    mty
                });
            }
        }

        // Enviar los datos al backend
        const response = await fetch('', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(shots)
        });

        if (response.ok) 
        {
            alert('Datos enviados correctamente');
            window.location.href = 'finot.php'; // Redirigir a finot.php
        } 
        else 
        {
            alert('Error al enviar los datos');
        }
        });
    </script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">

</body>
</html>