<?php
// Configuración de la conexión a la base de datos
$servername = "localhost"; // Cambia esto según tu servidor
$username = "root"; // Cambia esto por tu usuario
$password = ""; // Cambia esto por tu contraseña
$dbname = "controldistribucion"; // Cambia esto por tu base de datos

// Crear conexión
$conexion = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Inicializar la variable $ot
$ot = "";

// Ejecutar la consulta para obtener el número de OT
$query = "SELECT numero_ot FROM `ordenes_trabajo` LIMIT 1";
$result = $conexion->query($query);

// Verificar si hay resultados
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Obtener el número de OT y agregar el prefijo
    $ot = "OT-" . $row['numero_ot'];
} else {
    $ot = "OT-"; // Manejar el caso en que no haya resultados
}

// Manejar la inserción de productos
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['nombreEmpresa'])) {
    $nombre_producto = $_POST['nombreEmpresa'];
    $cantidad_producto = $_POST['cantidad_producto'];
    $bodega = $_POST['ejecutivo']; // Obtener bodega del formulario
    $fecha_estimada = $_POST['fecha_llegada']; // Obtener fecha estimada del formulario

    // Insertar en la base de datos
    $stmt = $conexion->prepare("INSERT INTO productobodega (ot, nombre_producto, cantidad, bodega, fecha_estimada) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiss", $ot, $nombre_producto, $cantidad_producto, $bodega, $fecha_estimada);
    $stmt->execute();
    $stmt->close();
}

// Obtener los productos de la base de datos
$productos = [];
$query = "SELECT * FROM productobodega WHERE ot = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("s", $ot);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $productos[] = $row;
}
$stmt->close();

// Manejar la eliminación de productos
if (isset($_POST['eliminar_id'])) {
    $eliminar_id = $_POST['eliminar_id'];
    $stmt = $conexion->prepare("DELETE FROM productobodega WHERE id = ?");
    $stmt->bind_param("i", $eliminar_id);
    $stmt->execute();
    $stmt->close();

    // Redireccionar para evitar reenvío del formulario
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Manejar la actualización de productos
if (isset($_POST['actualizar_id'])) {
    $actualizar_id = $_POST['actualizar_id'];
    $nuevo_nombre = $_POST['nuevo_nombre'];
    $nueva_cantidad = $_POST['nueva_cantidad'];
    $nueva_bodega = $_POST['nueva_bodega'];
    $nueva_fecha = $_POST['nueva_fecha'];

    $stmt = $conexion->prepare("UPDATE productobodega SET nombre_producto = ?, cantidad = ?, bodega = ?, fecha_estimada = ? WHERE id = ?");
    $stmt->bind_param("sissi", $nuevo_nombre, $nueva_cantidad, $nueva_bodega, $nueva_fecha, $actualizar_id);
    $stmt->execute();
    $stmt->close();

    // Redireccionar para evitar reenvío del formulario
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Cerrar la conexión
$conexion->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="../../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../../assets/img/favicon.png">
  <title>Medicable Control y Distribucion</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis .com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
  <link href="../../assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="../../assets/css/nucleo-svg.css" rel="stylesheet" />
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <link id="pagestyle" href="../../assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
</head>
<body class="g-sidenav-show bg-gray-200">
<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header">
      <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
      <a class="navbar-brand m-0" href="https://demos.creative-tim.com/material-dashboard/pages/dashboard" target="_blank">
        <img src="../../assets/img/logo-ct.png" class="navbar-brand-img h-100" alt="main_logo">
        <span class="ms-1 font-weight-bold text-white">Medicable</span>
      </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse w-auto" id="sidenav-collapse-main">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link text-white" href="../dashboard.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">dashboard</i>
            </div>
            <span class="nav-link-text ms-1">Dashboard</span>
          </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#ventas-dropdown" aria-controls="ventas-dropdown" aria-expanded="false" aria-label="Ventas">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                <i class="material-icons opacity-10">table_view</i>
                </div>
                <span class="nav-link-text ms-1">Ventas</span>
            </a>
            <div class="collapse show" id="ventas-dropdown">
                <ul class="navbar-nav">
                <li>
                    <a class="nav-link text-white" href="NuevaOT.php">
                    <span class="nav-link-text ms-1">Nueva OT</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link text-white active bg-gradient-primary" href="OrdenTrabajo.php">
                    <span class="nav-link-text ms-1">Crear Orden de Trabajo</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link text-white" href="OrdenesTrabajo.php">
                    <span class="nav-link-text ms-1">Ordenes de Trabajo</span>
                    </a>
                </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="../logistica/OrdenDistribucion.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">receipt_long</i>
            </div>
            <span class="nav-link-text ms-1">Logistica</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="../../pages/virtual-reality.html">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">view_in_ar</i>
            </div>
            <span class="nav-link-text ms-1">Almacen</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="../vehiculos/Vehiculos.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity- 10">format_textdirection_r_to_l</i>
            </div>
            <span class="nav-link-text ms-1">Vehiculos</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="../pages/notifications.html">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">notifications</i>
            </div>
            <span class="nav-link-text ms-1">Usuarios</span>
          </a>
        </li>
      </ul>
    </div>
    <div class="sidenav-footer position-absolute w-100 bottom-0">
      <div class="mx-3">
        <a class="btn bg-gradient-primary w-100" href="https://www.creative-tim.com/product/material-dashboard-pro?ref=sidebarfree" type="button">Cerrar Sesión</a>
      </div>
    </div>
</aside>
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
    <div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card card-sm my-4">                
            <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                    <h6 class="text-white text-capitalize ps-3">BODEGA: ENVÍO - RECEPCIÓN</h6>
                </div>
            </div>
            <div class="container-fluid py-4 d-flex justify-content-center align-items-center" style="min-height: 75vh;">
                <form class="needs-validation" method="POST" action="" novalidate style="width: 100%; max-width: 600px;">
                    <!-- Sección OT -->
                    <fieldset class="mb-4">
                        <div class="row mb-3">
                            <div class="col-md-3">
                                <label for="ot" class="form-label">OT:</label>
                                <input type="text" class="form-control" id="ot" name="ot" value="<?php echo htmlspecialchars($ot); ?>" readonly>
                                <div class="invalid-feedback">Por favor, ingrese un OT válido.</div>
                            </div>
                            <div class="col-md-5">
                                <label for="ejecutivo" class="form-label">Bodega:</label>
                                <select class="form-select" id="ejecutivo" name="ejecutivo" required>
                                    <option selected disabled value="">Seleccione una Bodega</option>
                                    <option value="Chihuahua">CDMX, Chihuahua</option>
                                    <option value="Desierto">CDMX, Desierto</option>
                                    <option value="Monterrey">MONTERREY, Monterrey</option>
                                    <option value="Guadalajara">GUADALAJARA, Guadalajara</option>
                                </select>
                                <div class="invalid-feedback">Por favor, seleccione una bodega.</div>
                            </div>
                            <div class="col-md-4">
                                <label for="fecha_llegada" class="form-label">Fecha Estimada de Llegada:</label>
                                <input type="date" class="form-control" id="fecha_llegada" name="fecha_llegada" required>
                                <div class="invalid-feedback">Por favor, seleccione una fecha.</div>
                            </div>
                        </div>
                    </fieldset>

                    <!-- Sección Producto -->
                    <fieldset class="mb-4">
                        <legend class="fw-bold">Agregar Productos a Bodegas</legend>
                        <div class="row mb-3">
                            <div class="col-md-8">
                              <label for="nombreEmpresa" class="form-label">Nombre del producto</label>
                              <input type="text" class="form-control" id="nombreEmpresa" name="nombreEmpresa" placeholder="" required>
                              <div class="invalid-feedback">Por favor, ingrese el nombre del producto.</div>
                            </div>
                            <div class="col-md-2">
                                <label for="cantidad_producto" class="form-label">Cantidad:</label>
                                <input type="number" class="form-control" id="cantidad_producto" name="cantidad_producto" required>
                                <div class="invalid-feedback">Por favor, ingrese la cantidad del producto.</div>
                            </div>
                            <div class="col-md-2">
                                <label for="agregar" class="form-label">Agregar:</label>
                                <button type="submit" class="btn btn-primary"> Agregar</button>
                            </div>
                        </div>
                    </fieldset>

                    <a href="OT-3.php" class="btn btn-success">Siguiente</a>                
                  </form>
                <br>
            </div>
            <div class="container-fluid py-4">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nombre del Producto</th>
                                <th>Cantidad</th>
                                <th>Bodega</th>
                                <th>Fecha Estimada</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($productos as $producto): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($producto['nombre_producto']); ?></td>
                                    <td><?php echo htmlspecialchars($producto['cantidad']); ?></td>
                                    <td><?php echo htmlspecialchars($producto['bodega']); ?></td>
                                    <td><?php echo htmlspecialchars($producto['fecha_estimada']); ?></td>
                                    <td>
                                        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $producto['id']; ?>">Editar</button>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="eliminar_id" value="<?php echo $producto['id']; ?>">
                                            <button type="submit" class="btn btn-danger">Eliminar</button>
                                        </form>
                                    </td>
                                </tr>

                                <!-- Modal para editar producto -->
                                <div class="modal fade" id="editModal<?php echo $producto['id']; ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editModalLabel">Editar Producto</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form method="POST">
                                                    <input type="hidden" name="actualizar_id" value="<?php echo $producto['id']; ?>">
                                                    <div class="mb-3">
                                                        <label for="nuevo_nombre" class="form-label">Nombre del Producto</label>
                                                        <input type="text" class="form-control" name="nuevo_nombre" value="<?php echo htmlspecialchars($producto['nombre_producto']); ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="nueva_cantidad" class="form-label">Nueva Cantidad</label>
                                                        <input type="number" class="form-control" name="nueva_cantidad" value="<?php echo htmlspecialchars($producto['cantidad']); ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="nueva_bodega" class="form-label">Bodega</label>
                                                        <select class="form-select" name="nueva_bodega" required>
                                                            <option value="Chihuahua" <?php echo ($producto['bodega'] == 'Chihuahua') ? 'selected' : ''; ?>>CDMX, Chihuahua</option>
                                                            <option value="Desierto" <?php echo ($producto['bodega'] == 'Desierto') ? 'selected' : ''; ?>>CDMX, Desierto</option>
                                                            <option value="Monterrey" <?php echo ($producto['bodega'] == 'Monterrey') ? 'selected' : ''; ?>>MONTERREY, Monterrey</option>
                                                            <option value="Guadalajara" <?php echo ($producto['bodega'] == 'Guadalajara') ? 'selected' : ''; ?>>GUADALAJARA, Guadalajara</option>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="nueva_fecha" class="form-label">Fecha Estimada</label>
                                                        <input type="date" class="form-control" name="nueva_fecha" value="<?php echo htmlspecialchars($producto['fecha_estimada']); ?>" required>
                                                    </div>
                                                    <button type="submit" class="btn btn-primary">Actualizar</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
        </div>
      </div>
      <footer class="footer py-4">
        <div class="container-fluid">
          <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
              <div class="copyright text-center text-sm text-muted text-lg-start">
                © ```html
                <script>
                  document.write(new Date().getFullYear())
                </script>,
                <i class="fa fa-heart"></i>
                <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Medicable</a>
                Todos los derechos reservados.
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </main>
  
  <!--   Core JS Files   -->
  <script src="../../assets/js/core/popper.min.js"></script>
  <script src="../../assets/js/core/bootstrap.min.js"></script>
  <script src="../../assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="../../assets/js/plugins/smooth-scrollbar.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
</body>
</html>